NES skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 36, 36, 1008 x 756 px (left clear: nothing is drawn there)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png               1044 x 864   px  the bezel around the game screen
  save.png                 209 x 90    px  a quick action on the frame, bind quickSave
  load.png                 209 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                208 x 90    px  a quick action on the frame, bind turbo
  slow-motion.png          209 x 90    px  a quick action on the frame, bind slowMotion
  fast-forward.png         209 x 90    px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 102   px  a button, bind menu
  dpad.png                 420 x 420   px  the D-pad, bind dpad
  dpad-ball.png            308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    180 x 180   px  a button, bind b
  a.png                    180 x 180   px  a button, bind a
  select.png               162 x 54    px  a button, bind select
  start.png                162 x 54    px  a button, bind start

phone-landscape/  (2238 x 1080 px)
  game screen at 491, 36, 1256 x 942 px (left clear: nothing is drawn there)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png               1292 x 1044  px  the bezel around the game screen
  save.png                 258 x 84    px  a quick action on the frame, bind quickSave
  load.png                 259 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                258 x 84    px  a quick action on the frame, bind turbo
  slow-motion.png          259 x 84    px  a quick action on the frame, bind slowMotion
  fast-forward.png         258 x 84    px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 90    px  a button, bind menu
  dpad.png                 361 x 362   px  the D-pad, bind dpad
  dpad-ball.png            265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    155 x 154   px  a button, bind b
  a.png                    155 x 154   px  a button, bind a
  select.png               162 x 54    px  a button, bind select
  start.png                162 x 54    px  a button, bind start

tablet-portrait/  (1600 x 2560 px)
  game screen at 52, 52, 1496 x 1122 px (left clear: nothing is drawn there)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1536 x 1230  px  the bezel around the game screen
  save.png                 307 x 88    px  a quick action on the frame, bind quickSave
  load.png                 307 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                308 x 88    px  a quick action on the frame, bind turbo
  slow-motion.png          307 x 88    px  a quick action on the frame, bind slowMotion
  fast-forward.png         307 x 88    px  a quick action on the frame, bind toggleFastForward
  menu.png                 104 x 84    px  a button, bind menu
  dpad.png                 314 x 314   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    134 x 134   px  a button, bind b
  a.png                    134 x 134   px  a button, bind a
  select.png               132 x 44    px  a button, bind select
  start.png                132 x 44    px  a button, bind start

tablet-landscape/  (2560 x 1600 px)
  game screen at 500, 181, 1560 x 1170 px (left clear: nothing is drawn there)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png               1600 x 1278  px  the bezel around the game screen
  save.png                 320 x 88    px  a quick action on the frame, bind quickSave
  load.png                 320 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                320 x 88    px  a quick action on the frame, bind turbo
  slow-motion.png          320 x 88    px  a quick action on the frame, bind slowMotion
  fast-forward.png         320 x 88    px  a quick action on the frame, bind toggleFastForward
  menu.png                 104 x 80    px  a button, bind menu
  dpad.png                 314 x 314   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    134 x 134   px  a button, bind b
  a.png                    134 x 134   px  a button, bind a
  select.png               132 x 44    px  a button, bind select
  start.png                132 x 44    px  a button, bind start

fold-portrait/  (1812 x 2178 px)
  game screen at 325, 78, 1162 x 871 px (left clear: nothing is drawn there)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png               1222 x 1033  px  the bezel around the game screen
  save.png                 244 x 132   px  a quick action on the frame, bind quickSave
  load.png                 245 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                244 x 132   px  a quick action on the frame, bind turbo
  slow-motion.png          245 x 132   px  a quick action on the frame, bind slowMotion
  fast-forward.png         244 x 132   px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 126   px  a button, bind menu
  dpad.png                 350 x 350   px  the D-pad, bind dpad
  dpad-ball.png            257 x 257   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    150 x 150   px  a button, bind b
  a.png                    150 x 150   px  a button, bind a
  select.png               198 x 66    px  a button, bind select
  start.png                198 x 66    px  a button, bind start

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 488, 978 x 734 px (left clear: nothing is drawn there)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 896   px  the bezel around the game screen
  save.png                 208 x 132   px  a quick action on the frame, bind quickSave
  load.png                 207 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                208 x 132   px  a quick action on the frame, bind turbo
  slow-motion.png          207 x 132   px  a quick action on the frame, bind slowMotion
  fast-forward.png         208 x 132   px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 120   px  a button, bind menu
  dpad.png                 470 x 470   px  the D-pad, bind dpad
  dpad-ball.png            345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    202 x 202   px  a button, bind b
  a.png                    202 x 202   px  a button, bind a
  select.png               198 x 66    px  a button, bind select
  start.png                198 x 66    px  a button, bind start

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, FC-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/FC/ on the device.
  3. Start a NES game. Delete the folder to go back to the bundled skin.
