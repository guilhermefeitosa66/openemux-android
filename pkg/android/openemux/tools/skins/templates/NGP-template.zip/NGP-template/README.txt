Neo Geo Pocket skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 45, 36, 990 x 940 px (left clear: nothing is drawn there)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png               1026 x 1048  px  the bezel around the game screen
  save.png                 257 x 90    px  a quick action on the frame, bind quickSave
  load.png                 256 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                257 x 90    px  a quick action on the frame, bind turbo
  fast-forward.png         256 x 90    px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 102   px  a button, bind menu
  dpad.png                 420 x 420   px  the D-pad, bind dpad
  dpad-ball.png            308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  a.png                    186 x 186   px  a button, bind a
  b.png                    186 x 186   px  a button, bind b
  start.png                162 x 54    px  a button, bind start

phone-landscape/  (2238 x 1080 px)
  game screen at 623, 36, 992 x 942 px (left clear: nothing is drawn there)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png               1028 x 1044  px  the bezel around the game screen
  save.png                 257 x 84    px  a quick action on the frame, bind quickSave
  load.png                 257 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                257 x 84    px  a quick action on the frame, bind turbo
  fast-forward.png         257 x 84    px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 90    px  a button, bind menu
  dpad.png                 361 x 362   px  the D-pad, bind dpad
  dpad-ball.png            265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  a.png                    159 x 160   px  a button, bind a
  b.png                    160 x 160   px  a button, bind b
  start.png                162 x 54    px  a button, bind start

tablet-portrait/  (1600 x 2560 px)
  game screen at 126, 52, 1348 x 1280 px (left clear: nothing is drawn there)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1388 x 1388  px  the bezel around the game screen
  save.png                 347 x 88    px  a quick action on the frame, bind quickSave
  load.png                 347 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                347 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         347 x 88    px  a quick action on the frame, bind toggleFastForward
  menu.png                 104 x 84    px  a button, bind menu
  dpad.png                 314 x 313   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  a.png                    139 x 138   px  a button, bind a
  b.png                    139 x 139   px  a button, bind b
  start.png                132 x 44    px  a button, bind start

tablet-landscape/  (2560 x 1600 px)
  game screen at 528, 52, 1504 x 1428 px (left clear: nothing is drawn there)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png               1544 x 1536  px  the bezel around the game screen
  save.png                 386 x 88    px  a quick action on the frame, bind quickSave
  load.png                 386 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                386 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         386 x 88    px  a quick action on the frame, bind toggleFastForward
  menu.png                 104 x 80    px  a button, bind menu
  dpad.png                 314 x 314   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  a.png                    139 x 139   px  a button, bind a
  b.png                    139 x 139   px  a button, bind b
  start.png                132 x 44    px  a button, bind start

fold-portrait/  (1812 x 2178 px)
  game screen at 448, 78, 917 x 871 px (left clear: nothing is drawn there)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png                977 x 1033  px  the bezel around the game screen
  save.png                 244 x 132   px  a quick action on the frame, bind quickSave
  load.png                 244 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                244 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         244 x 132   px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 126   px  a button, bind menu
  dpad.png                 350 x 350   px  the D-pad, bind dpad
  dpad-ball.png            257 x 257   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  a.png                    154 x 155   px  a button, bind a
  b.png                    154 x 155   px  a button, bind b
  start.png                198 x 66    px  a button, bind start

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 390, 978 x 929 px (left clear: nothing is drawn there)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 1091  px  the bezel around the game screen
  save.png                 260 x 132   px  a quick action on the frame, bind quickSave
  load.png                 259 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                260 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         259 x 132   px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 120   px  a button, bind menu
  dpad.png                 470 x 470   px  the D-pad, bind dpad
  dpad-ball.png            345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  a.png                    208 x 208   px  a button, bind a
  b.png                    208 x 209   px  a button, bind b
  start.png                198 x 66    px  a button, bind start

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, NGP-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/NGP/ on the device.
  3. Start a Neo Geo Pocket game. Delete the folder to go back to the bundled skin.
