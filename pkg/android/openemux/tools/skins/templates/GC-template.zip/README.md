# GameCube skin template

A skin package for OpenEmux on Android, with plain placeholder art at the exact sizes the app reads. Repaint the
images, keep the file names and sizes, zip the files again and install it. The guide that explains the format,
every input name and the install steps is `tools/skins/templates/README.md` in the openemux-android repository:
<https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md>

## Files

- `info.json`: the layouts, with every control placed and bound. Positions are in mapping units, not pixels.
- The PNG images below: the art, one per layout. The screens are transparent holes.
- `sources/`: one SVG per PNG, the image's editable source. Each control is a layer named after its input
  (`a`, `start`, `dpad`, `analogStick`...); two hidden layers show where the screens are (`screen-guides`)
  and how far each control's touch area reaches (`touch-areas`). Export each SVG to its PNG at the size below.
- `README.md`: this file.

`sources/` and `README.md` are optional in the installed package: the app reads only `info.json` and the images it
names.

## Layout art

| Image | Layout | Mapping size (units) | Image size | Screen frame(s) (x, y, w x h, units) |
|---|---|---|---|---|
| `phone_portrait.png` | phone portrait | 360 x 746 | 1080 x 2238 px | 12, 12, 336 x 252 |
| `phone_landscape.png` | phone landscape | 746 x 360 | 2238 x 1080 px | 163.7, 12, 418.7 x 314 |
| `tablet_portrait.png` | tablet portrait | 800 x 1280 | 1600 x 2560 px | 26, 26, 748 x 561 |
| `tablet_landscape.png` | tablet landscape | 1280 x 800 | 2560 x 1600 px | 250, 90.5, 780 x 585 |

## Knobs

| Image | Size | What it is |
|---|---|---|
| `phone_portrait_knob0.png` | 218 x 218 px | a stick's knob, moved by the thumb over the stick's well |
| `phone_portrait_knob1.png` | 156 x 156 px | a stick's knob, moved by the thumb over the stick's well |
| `phone_landscape_knob0.png` | 165 x 165 px | a stick's knob, moved by the thumb over the stick's well |
| `phone_landscape_knob1.png` | 118 x 118 px | a stick's knob, moved by the thumb over the stick's well |
| `tablet_portrait_knob0.png` | 163 x 163 px | a stick's knob, moved by the thumb over the stick's well |
| `tablet_portrait_knob1.png` | 116 x 116 px | a stick's knob, moved by the thumb over the stick's well |
| `tablet_landscape_knob0.png` | 163 x 163 px | a stick's knob, moved by the thumb over the stick's well |
| `tablet_landscape_knob1.png` | 116 x 116 px | a stick's knob, moved by the thumb over the stick's well |
| `dpad_knob.png` | 400 x 400 px | the D-pad's circle, stretched over the D-pad's travel and moved by the thumb |

## Controls

The inputs of the phone portrait layout, in drawing order (the other layouts have the same ones):

- `quickSave`
- `quickLoad`
- `turbo`
- `toggleFastForward`
- `l`
- `z`
- `r`
- `menu`
- `analogStick`
- `a`
- `b`
- `x`
- `y`
- `dpad`
- `rightAnalogStick`
- `start`

## Install

1. Zip the files so that `info.json` sits at the zip's root (not inside a folder).
2. Name the zip `GC.manicskin`.
3. Copy it to `Android/data/com.openemux.mobile/files/skins/GC/` on the device, then start a game.
   Delete it to go back to the bundled skin.
