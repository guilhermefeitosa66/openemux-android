GameCube skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 36, 36, 1008 x 756 px (left clear: nothing is drawn there)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png               1044 x 864   px  the bezel around the game screen
  save.png                 261 x 90    px  a quick action on the frame, bind quickSave
  load.png                 261 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                261 x 90    px  a quick action on the frame, bind turbo
  fast-forward.png         261 x 90    px  a quick action on the frame, bind toggleFastForward
  l.png                    372 x 120   px  a button, bind l
  z.png                    186 x 120   px  a button, bind z
  r.png                    186 x 120   px  a button, bind r
  menu.png                 156 x 102   px  a button, bind menu
  stick-base.png           336 x 336   px  the stick's well, bind analogStick
  stick-knob.png           168 x 168   px  the stick's knob, moved by the thumb, bind analogStick
  a.png                    222 x 222   px  a button, bind a
  b.png                    126 x 126   px  a button, bind b
  x.png                    102 x 186   px  a button, bind x
  y.png                    186 x 102   px  a button, bind y
  dpad.png                 300 x 300   px  the D-pad, bind dpad
  dpad-ball.png            220 x 220   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  stick2-base.png          240 x 240   px  the stick's well, bind rightAnalogStick
  stick2-knob.png          120 x 120   px  the stick's knob, moved by the thumb, bind rightAnalogStick
  start.png                162 x 54    px  a button, bind start

phone-landscape/  (2238 x 1080 px)
  game screen at 491, 36, 1256 x 942 px (left clear: nothing is drawn there)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png               1292 x 1044  px  the bezel around the game screen
  save.png                 323 x 84    px  a quick action on the frame, bind quickSave
  load.png                 323 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                323 x 84    px  a quick action on the frame, bind turbo
  fast-forward.png         323 x 84    px  a quick action on the frame, bind toggleFastForward
  l.png                    372 x 114   px  a button, bind l
  z.png                    188 x 114   px  a button, bind z
  r.png                    188 x 114   px  a button, bind r
  menu.png                 156 x 90    px  a button, bind menu
  stick-base.png           254 x 254   px  the stick's well, bind analogStick
  stick-knob.png           127 x 127   px  the stick's knob, moved by the thumb, bind analogStick
  a.png                    168 x 168   px  a button, bind a
  b.png                     95 x 95    px  a button, bind b
  x.png                     77 x 140   px  a button, bind x
  y.png                    141 x 77    px  a button, bind y
  dpad.png                 227 x 227   px  the D-pad, bind dpad
  dpad-ball.png            166 x 166   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  stick2-base.png          181 x 181   px  the stick's well, bind rightAnalogStick
  stick2-knob.png           91 x 91    px  the stick's knob, moved by the thumb, bind rightAnalogStick
  start.png                162 x 54    px  a button, bind start

tablet-portrait/  (1600 x 2560 px)
  game screen at 52, 52, 1496 x 1122 px (left clear: nothing is drawn there)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1536 x 1230  px  the bezel around the game screen
  save.png                 384 x 88    px  a quick action on the frame, bind quickSave
  load.png                 384 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                384 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         384 x 88    px  a quick action on the frame, bind toggleFastForward
  l.png                    340 x 96    px  a button, bind l
  z.png                    340 x 96    px  a button, bind z
  r.png                    340 x 96    px  a button, bind r
  menu.png                 104 x 84    px  a button, bind menu
  stick-base.png           250 x 250   px  the stick's well, bind analogStick
  stick-knob.png           125 x 125   px  the stick's knob, moved by the thumb, bind analogStick
  a.png                    166 x 166   px  a button, bind a
  b.png                     94 x 94    px  a button, bind b
  x.png                     76 x 139   px  a button, bind x
  y.png                    139 x 76    px  a button, bind y
  dpad.png                 224 x 224   px  the D-pad, bind dpad
  dpad-ball.png            164 x 164   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  stick2-base.png          180 x 180   px  the stick's well, bind rightAnalogStick
  stick2-knob.png           90 x 90    px  the stick's knob, moved by the thumb, bind rightAnalogStick
  start.png                132 x 44    px  a button, bind start

tablet-landscape/  (2560 x 1600 px)
  game screen at 500, 181, 1560 x 1170 px (left clear: nothing is drawn there)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png               1600 x 1278  px  the bezel around the game screen
  save.png                 400 x 88    px  a quick action on the frame, bind quickSave
  load.png                 400 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                400 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         400 x 88    px  a quick action on the frame, bind toggleFastForward
  l.png                    340 x 96    px  a button, bind l
  z.png                    208 x 96    px  a button, bind z
  r.png                    208 x 96    px  a button, bind r
  menu.png                 104 x 80    px  a button, bind menu
  stick-base.png           250 x 251   px  the stick's well, bind analogStick
  stick-knob.png           125 x 125   px  the stick's knob, moved by the thumb, bind analogStick
  a.png                    166 x 166   px  a button, bind a
  b.png                     94 x 94    px  a button, bind b
  x.png                     76 x 139   px  a button, bind x
  y.png                    139 x 77    px  a button, bind y
  dpad.png                 224 x 224   px  the D-pad, bind dpad
  dpad-ball.png            164 x 164   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  stick2-base.png          180 x 179   px  the stick's well, bind rightAnalogStick
  stick2-knob.png           90 x 90    px  the stick's knob, moved by the thumb, bind rightAnalogStick
  start.png                132 x 44    px  a button, bind start

fold-portrait/  (1812 x 2178 px)
  game screen at 325, 78, 1162 x 871 px (left clear: nothing is drawn there)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png               1222 x 1033  px  the bezel around the game screen
  save.png                 306 x 132   px  a quick action on the frame, bind quickSave
  load.png                 305 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                305 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         306 x 132   px  a quick action on the frame, bind toggleFastForward
  l.png                    510 x 144   px  a button, bind l
  z.png                    369 x 144   px  a button, bind z
  r.png                    369 x 144   px  a button, bind r
  menu.png                 156 x 126   px  a button, bind menu
  stick-base.png           164 x 164   px  the stick's well, bind analogStick
  stick-knob.png            82 x 82    px  the stick's knob, moved by the thumb, bind analogStick
  a.png                    108 x 108   px  a button, bind a
  b.png                     62 x 62    px  a button, bind b
  x.png                     49 x 91    px  a button, bind x
  y.png                     91 x 49    px  a button, bind y
  dpad.png                 146 x 147   px  the D-pad, bind dpad
  dpad-ball.png            107 x 107   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  stick2-base.png          117 x 117   px  the stick's well, bind rightAnalogStick
  stick2-knob.png           59 x 59    px  the stick's knob, moved by the thumb, bind rightAnalogStick
  start.png                198 x 66    px  a button, bind start

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 488, 978 x 734 px (left clear: nothing is drawn there)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 896   px  the bezel around the game screen
  save.png                 260 x 132   px  a quick action on the frame, bind quickSave
  load.png                 259 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                260 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         259 x 132   px  a quick action on the frame, bind toggleFastForward
  l.png                    498 x 144   px  a button, bind l
  z.png                    237 x 144   px  a button, bind z
  r.png                    237 x 144   px  a button, bind r
  menu.png                 156 x 120   px  a button, bind menu
  stick-base.png           376 x 376   px  the stick's well, bind analogStick
  stick-knob.png           188 x 188   px  the stick's knob, moved by the thumb, bind analogStick
  a.png                    219 x 219   px  a button, bind a
  b.png                    125 x 124   px  a button, bind b
  x.png                    100 x 184   px  a button, bind x
  y.png                    184 x 101   px  a button, bind y
  dpad.png                 336 x 336   px  the D-pad, bind dpad
  dpad-ball.png            246 x 246   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  stick2-base.png          268 x 269   px  the stick's well, bind rightAnalogStick
  stick2-knob.png          134 x 134   px  the stick's knob, moved by the thumb, bind rightAnalogStick
  start.png                198 x 66    px  a button, bind start

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, GC-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/GC/ on the device.
  3. Start a GameCube game. Delete the folder to go back to the bundled skin.
