# Nintendo DS skin template

A skin package for OpenEmux on Android, with plain placeholder art at the exact sizes the app reads. Repaint the
images, keep the file names and sizes, zip the files again and install it. The guide that explains the format,
every input name and the install steps is `tools/skins/templates/README.md` in the openemux-android repository:
<https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md>

## Files

- `info.json`: the layouts, with every control placed and bound. Positions are in mapping units, not pixels.
- The PNG images below: the art, one per layout. The screens are transparent holes.
- `sources/`: one SVG per PNG, the image's editable source. Each control is a layer named after its input
  (`a`, `start`, `dpad`, `analogStick`...); two hidden layers show where the screens are (`screen-guides`)
  and how far each control's touch area reaches (`touch-areas`). Export each SVG to its PNG at the size below.
- `README.md`: this file.

`sources/` and `README.md` are optional in the installed package: the app reads only `info.json` and the images it
names.

## Layout art

| Image | Layout | Mapping size (units) | Image size | Screen frame(s) (x, y, w x h, units) |
|---|---|---|---|---|
| `phone_portrait.png` | phone portrait | 360 x 746 | 1080 x 2238 px | 40.7, 12, 278.5 x 208.9; 40.7, 220.9, 278.5 x 208.9 |
| `phone_portrait_top.png` | phone portrait, top layout | 360 x 746 | 1080 x 2238 px | 12, 12, 336 x 252 |
| `phone_portrait_bottom.png` | phone portrait, bottom layout | 360 x 746 | 1080 x 2238 px | 12, 12, 336 x 252 |
| `phone_portrait_side.png` | phone portrait, side layout | 360 x 746 | 1080 x 2238 px | 12, 12, 168 x 126; 180, 12, 168 x 126 |
| `phone_landscape.png` | phone landscape | 746 x 360 | 2238 x 1080 px | 268.3, 12, 209.3 x 157; 268.3, 169, 209.3 x 157 |
| `phone_landscape_top.png` | phone landscape, top layout | 746 x 360 | 2238 x 1080 px | 163.7, 12, 418.7 x 314 |
| `phone_landscape_bottom.png` | phone landscape, bottom layout | 746 x 360 | 2238 x 1080 px | 163.7, 12, 418.7 x 314 |
| `phone_landscape_side.png` | phone landscape, side layout | 746 x 360 | 2238 x 1080 px | 156, 87.6, 217 x 162.8; 373, 87.6, 217 x 162.8 |
| `tablet_portrait.png` | tablet portrait | 800 x 1280 | 1600 x 2560 px | 144, 26, 512 x 384; 144, 410, 512 x 384 |
| `tablet_portrait_top.png` | tablet portrait, top layout | 800 x 1280 | 1600 x 2560 px | 26, 26, 748 x 561 |
| `tablet_portrait_bottom.png` | tablet portrait, bottom layout | 800 x 1280 | 1600 x 2560 px | 26, 26, 748 x 561 |
| `tablet_portrait_side.png` | tablet portrait, side layout | 800 x 1280 | 1600 x 2560 px | 26, 26, 374 x 280.5; 400, 26, 374 x 280.5 |
| `tablet_landscape.png` | tablet landscape | 1280 x 800 | 2560 x 1600 px | 402, 26, 476 x 357; 402, 383, 476 x 357 |
| `tablet_landscape_top.png` | tablet landscape, top layout | 1280 x 800 | 2560 x 1600 px | 250, 90.5, 780 x 585 |
| `tablet_landscape_bottom.png` | tablet landscape, bottom layout | 1280 x 800 | 2560 x 1600 px | 250, 90.5, 780 x 585 |
| `tablet_landscape_side.png` | tablet landscape, side layout | 1280 x 800 | 2560 x 1600 px | 250, 236.8, 390 x 292.5; 640, 236.8, 390 x 292.5 |

## Knobs

| Image | Size | What it is |
|---|---|---|
| `dpad_knob.png` | 400 x 400 px | the D-pad's circle, stretched over the D-pad's travel and moved by the thumb |

## Controls

The inputs of the phone portrait layout, in drawing order (the other layouts have the same ones):

- `quickSave`
- `quickLoad`
- `turbo`
- `toggleFastForward`
- `screens`
- `l`
- `r`
- `menu`
- `dpad`
- `x`
- `y`
- `a`
- `b`
- `select`
- `start`

## Install

1. Zip the files so that `info.json` sits at the zip's root (not inside a folder).
2. Name the zip `NDS.deltaskin`.
3. Copy it to `Android/data/com.openemux.mobile/files/skins/NDS/` on the device, then start a game.
   Delete it to go back to the bundled skin.
