Nintendo DS skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 122, 36, 836 x 627 px (left clear: nothing is drawn there)
  game screen at 122, 663, 836 x 626 px (left clear: nothing is drawn there)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png                872 x 1361  px  the bezel around the game screen
  save.png                 174 x 90    px  a quick action on the frame, bind quickSave
  load.png                 175 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                174 x 90    px  a quick action on the frame, bind turbo
  fast-forward.png         175 x 90    px  a quick action on the frame, bind toggleFastForward
  screens.png              174 x 90    px  a quick action on the frame, bind screens
  l.png                    372 x 120   px  a button, bind l
  r.png                    372 x 120   px  a button, bind r
  menu.png                 156 x 102   px  a button, bind menu
  dpad.png                 356 x 356   px  the D-pad, bind dpad
  dpad-ball.png            261 x 261   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    117 x 117   px  a button, bind x
  y.png                    117 x 117   px  a button, bind y
  a.png                    117 x 117   px  a button, bind a
  b.png                    117 x 117   px  a button, bind b
  select.png               162 x 54    px  a button, bind select
  start.png                162 x 54    px  a button, bind start

phone-landscape/  (2238 x 1080 px)
  game screen at 805, 36, 628 x 471 px (left clear: nothing is drawn there)
  game screen at 805, 507, 628 x 471 px (left clear: nothing is drawn there)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png                664 x 1044  px  the bezel around the game screen
  save.png                 133 x 84    px  a quick action on the frame, bind quickSave
  load.png                 133 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                132 x 84    px  a quick action on the frame, bind turbo
  fast-forward.png         133 x 84    px  a quick action on the frame, bind toggleFastForward
  screens.png              133 x 84    px  a quick action on the frame, bind screens
  l.png                    372 x 114   px  a button, bind l
  r.png                    372 x 114   px  a button, bind r
  menu.png                 156 x 90    px  a button, bind menu
  dpad.png                 361 x 362   px  the D-pad, bind dpad
  dpad-ball.png            265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    119 x 119   px  a button, bind x
  y.png                    119 x 118   px  a button, bind y
  a.png                    118 x 118   px  a button, bind a
  b.png                    119 x 119   px  a button, bind b
  select.png               162 x 54    px  a button, bind select
  start.png                162 x 54    px  a button, bind start

tablet-portrait/  (1600 x 2560 px)
  game screen at 288, 52, 1024 x 768 px (left clear: nothing is drawn there)
  game screen at 288, 820, 1024 x 768 px (left clear: nothing is drawn there)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1064 x 1644  px  the bezel around the game screen
  save.png                 213 x 88    px  a quick action on the frame, bind quickSave
  load.png                 213 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                212 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         213 x 88    px  a quick action on the frame, bind toggleFastForward
  screens.png              213 x 88    px  a quick action on the frame, bind screens
  l.png                    340 x 96    px  a button, bind l
  r.png                    340 x 96    px  a button, bind r
  menu.png                 104 x 84    px  a button, bind menu
  dpad.png                 314 x 314   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    103 x 103   px  a button, bind x
  y.png                    103 x 103   px  a button, bind y
  a.png                    103 x 103   px  a button, bind a
  b.png                    103 x 103   px  a button, bind b
  select.png               132 x 44    px  a button, bind select
  start.png                132 x 44    px  a button, bind start

tablet-landscape/  (2560 x 1600 px)
  game screen at 804, 52, 952 x 714 px (left clear: nothing is drawn there)
  game screen at 804, 766, 952 x 714 px (left clear: nothing is drawn there)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png                992 x 1536  px  the bezel around the game screen
  save.png                 198 x 88    px  a quick action on the frame, bind quickSave
  load.png                 199 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                198 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         199 x 88    px  a quick action on the frame, bind toggleFastForward
  screens.png              198 x 88    px  a quick action on the frame, bind screens
  l.png                    340 x 96    px  a button, bind l
  r.png                    340 x 96    px  a button, bind r
  menu.png                 104 x 80    px  a button, bind menu
  dpad.png                 314 x 314   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    103 x 103   px  a button, bind x
  y.png                    103 x 103   px  a button, bind y
  a.png                    103 x 103   px  a button, bind a
  b.png                    103 x 103   px  a button, bind b
  select.png               132 x 44    px  a button, bind select
  start.png                132 x 44    px  a button, bind start

fold-portrait/  (1812 x 2178 px)
  game screen at 543, 78, 726 x 545 px (left clear: nothing is drawn there)
  game screen at 543, 623, 726 x 544 px (left clear: nothing is drawn there)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png                786 x 1251  px  the bezel around the game screen
  save.png                 157 x 132   px  a quick action on the frame, bind quickSave
  load.png                 157 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                158 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         157 x 132   px  a quick action on the frame, bind toggleFastForward
  screens.png              157 x 132   px  a quick action on the frame, bind screens
  l.png                    510 x 144   px  a button, bind l
  r.png                    510 x 144   px  a button, bind r
  menu.png                 156 x 126   px  a button, bind menu
  dpad.png                 170 x 170   px  the D-pad, bind dpad
  dpad-ball.png            125 x 125   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                     56 x 56    px  a button, bind x
  y.png                     56 x 56    px  a button, bind y
  a.png                     56 x 56    px  a button, bind a
  b.png                     56 x 56    px  a button, bind b
  select.png               198 x 66    px  a button, bind select
  start.png                198 x 66    px  a button, bind start

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 122, 978 x 733 px (left clear: nothing is drawn there)
  game screen at 600, 855, 978 x 734 px (left clear: nothing is drawn there)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 1629  px  the bezel around the game screen
  save.png                 208 x 132   px  a quick action on the frame, bind quickSave
  load.png                 207 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                208 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         207 x 132   px  a quick action on the frame, bind toggleFastForward
  screens.png              208 x 132   px  a quick action on the frame, bind screens
  l.png                    498 x 144   px  a button, bind l
  r.png                    498 x 144   px  a button, bind r
  menu.png                 156 x 120   px  a button, bind menu
  dpad.png                 470 x 470   px  the D-pad, bind dpad
  dpad-ball.png            345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    154 x 154   px  a button, bind x
  y.png                    154 x 154   px  a button, bind y
  a.png                    154 x 154   px  a button, bind a
  b.png                    154 x 154   px  a button, bind b
  select.png               198 x 66    px  a button, bind select
  start.png                198 x 66    px  a button, bind start

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, NDS-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/NDS/ on the device.
  3. Start a Nintendo DS game. Delete the folder to go back to the bundled skin.
