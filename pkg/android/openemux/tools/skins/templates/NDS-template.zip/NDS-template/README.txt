Nintendo DS skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 122, 36, 836 x 627 px (left clear: nothing is drawn there)
  game screen at 122, 663, 836 x 626 px (left clear: nothing is drawn there)
  top/ game screen at 36, 36, 1008 x 756 px (its screen-layout page)
  bottom/ game screen at 36, 36, 1008 x 756 px (its screen-layout page)
  side/ game screen at 36, 36, 504 x 378 px (its screen-layout page)
  side/ game screen at 540, 36, 504 x 378 px (its screen-layout page)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png                872 x 1361  px  the bezel around the game screen
  save.png                 174 x 90    px  a quick action on the frame, bind quickSave
  load.png                 175 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                174 x 90    px  a quick action on the frame, bind turbo
  fast-forward.png         175 x 90    px  a quick action on the frame, bind toggleFastForward
  screens.png              174 x 90    px  a quick action on the frame, bind screens
  l.png                    372 x 129   px  a button, bind l
  r.png                    372 x 129   px  a button, bind r
  menu.png                 156 x 108   px  a button, bind menu
  dpad.png                 356 x 368   px  the D-pad, bind dpad
  dpad-ball.png            261 x 261   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    117 x 124   px  a button, bind x
  y.png                    117 x 125   px  a button, bind y
  a.png                    117 x 125   px  a button, bind a
  b.png                    117 x 125   px  a button, bind b
  select.png               162 x 60    px  a button, bind select
  start.png                162 x 60    px  a button, bind start
  top/background.png      1080 x 2238  px  the top page, behind everything
  top/frame.png           1044 x 864   px  the top page's bezel
  top/save.png             209 x 90    px  a quick action on the frame, bind quickSave
  top/load.png             209 x 90    px  a quick action on the frame, bind quickLoad
  top/turbo.png            208 x 90    px  a quick action on the frame, bind turbo
  top/fast-forward.png     209 x 90    px  a quick action on the frame, bind toggleFastForward
  top/screens.png          209 x 90    px  a quick action on the frame, bind screens
  top/l.png                372 x 129   px  a button, bind l
  top/r.png                372 x 129   px  a button, bind r
  top/menu.png             156 x 108   px  a button, bind menu
  top/dpad.png             420 x 432   px  the D-pad, bind dpad
  top/dpad-ball.png        308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  top/x.png                138 x 147   px  a button, bind x
  top/y.png                138 x 147   px  a button, bind y
  top/a.png                138 x 147   px  a button, bind a
  top/b.png                138 x 147   px  a button, bind b
  top/select.png           162 x 60    px  a button, bind select
  top/start.png            162 x 60    px  a button, bind start
  bottom/background.png   1080 x 2238  px  the bottom page, behind everything
  bottom/frame.png        1044 x 864   px  the bottom page's bezel
  bottom/save.png          209 x 90    px  a quick action on the frame, bind quickSave
  bottom/load.png          209 x 90    px  a quick action on the frame, bind quickLoad
  bottom/turbo.png         208 x 90    px  a quick action on the frame, bind turbo
  bottom/fast-forward.png   209 x 90    px  a quick action on the frame, bind toggleFastForward
  bottom/screens.png       209 x 90    px  a quick action on the frame, bind screens
  bottom/l.png             372 x 129   px  a button, bind l
  bottom/r.png             372 x 129   px  a button, bind r
  bottom/menu.png          156 x 108   px  a button, bind menu
  bottom/dpad.png          420 x 432   px  the D-pad, bind dpad
  bottom/dpad-ball.png     308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  bottom/x.png             138 x 147   px  a button, bind x
  bottom/y.png             138 x 147   px  a button, bind y
  bottom/a.png             138 x 147   px  a button, bind a
  bottom/b.png             138 x 147   px  a button, bind b
  bottom/select.png        162 x 60    px  a button, bind select
  bottom/start.png         162 x 60    px  a button, bind start
  side/background.png     1080 x 2238  px  the side page, behind everything
  side/frame.png          1044 x 486   px  the side page's bezel
  side/save.png            209 x 90    px  a quick action on the frame, bind quickSave
  side/load.png            209 x 90    px  a quick action on the frame, bind quickLoad
  side/turbo.png           208 x 90    px  a quick action on the frame, bind turbo
  side/fast-forward.png    209 x 90    px  a quick action on the frame, bind toggleFastForward
  side/screens.png         209 x 90    px  a quick action on the frame, bind screens
  side/l.png               372 x 129   px  a button, bind l
  side/r.png               372 x 129   px  a button, bind r
  side/menu.png            156 x 108   px  a button, bind menu
  side/dpad.png            420 x 432   px  the D-pad, bind dpad
  side/dpad-ball.png       308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  side/x.png               138 x 147   px  a button, bind x
  side/y.png               138 x 147   px  a button, bind y
  side/a.png               138 x 147   px  a button, bind a
  side/b.png               138 x 147   px  a button, bind b
  side/select.png          162 x 60    px  a button, bind select
  side/start.png           162 x 60    px  a button, bind start

phone-landscape/  (2238 x 1080 px)
  game screen at 805, 36, 628 x 471 px (left clear: nothing is drawn there)
  game screen at 805, 507, 628 x 471 px (left clear: nothing is drawn there)
  top/ game screen at 491, 36, 1256 x 942 px (its screen-layout page)
  bottom/ game screen at 491, 36, 1256 x 942 px (its screen-layout page)
  side/ game screen at 468, 263, 651 x 488 px (its screen-layout page)
  side/ game screen at 1119, 263, 651 x 488 px (its screen-layout page)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png                664 x 1044  px  the bezel around the game screen
  save.png                 133 x 84    px  a quick action on the frame, bind quickSave
  load.png                 133 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                132 x 84    px  a quick action on the frame, bind turbo
  fast-forward.png         133 x 84    px  a quick action on the frame, bind toggleFastForward
  screens.png              133 x 84    px  a quick action on the frame, bind screens
  l.png                    372 x 123   px  a button, bind l
  r.png                    372 x 123   px  a button, bind r
  menu.png                 156 x 96    px  a button, bind menu
  dpad.png                 361 x 374   px  the D-pad, bind dpad
  dpad-ball.png            265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    119 x 127   px  a button, bind x
  y.png                    119 x 126   px  a button, bind y
  a.png                    118 x 126   px  a button, bind a
  b.png                    119 x 126   px  a button, bind b
  select.png               162 x 60    px  a button, bind select
  start.png                162 x 60    px  a button, bind start
  top/background.png      2238 x 1080  px  the top page, behind everything
  top/frame.png           1292 x 1044  px  the top page's bezel
  top/save.png             258 x 84    px  a quick action on the frame, bind quickSave
  top/load.png             259 x 84    px  a quick action on the frame, bind quickLoad
  top/turbo.png            258 x 84    px  a quick action on the frame, bind turbo
  top/fast-forward.png     259 x 84    px  a quick action on the frame, bind toggleFastForward
  top/screens.png          258 x 84    px  a quick action on the frame, bind screens
  top/l.png                372 x 123   px  a button, bind l
  top/r.png                372 x 123   px  a button, bind r
  top/menu.png             156 x 96    px  a button, bind menu
  top/dpad.png             361 x 374   px  the D-pad, bind dpad
  top/dpad-ball.png        265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  top/x.png                119 x 127   px  a button, bind x
  top/y.png                119 x 126   px  a button, bind y
  top/a.png                119 x 126   px  a button, bind a
  top/b.png                119 x 126   px  a button, bind b
  top/select.png           162 x 60    px  a button, bind select
  top/start.png            162 x 60    px  a button, bind start
  bottom/background.png   2238 x 1080  px  the bottom page, behind everything
  bottom/frame.png        1292 x 1044  px  the bottom page's bezel
  bottom/save.png          258 x 84    px  a quick action on the frame, bind quickSave
  bottom/load.png          259 x 84    px  a quick action on the frame, bind quickLoad
  bottom/turbo.png         258 x 84    px  a quick action on the frame, bind turbo
  bottom/fast-forward.png   259 x 84    px  a quick action on the frame, bind toggleFastForward
  bottom/screens.png       258 x 84    px  a quick action on the frame, bind screens
  bottom/l.png             372 x 123   px  a button, bind l
  bottom/r.png             372 x 123   px  a button, bind r
  bottom/menu.png          156 x 96    px  a button, bind menu
  bottom/dpad.png          361 x 374   px  the D-pad, bind dpad
  bottom/dpad-ball.png     265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  bottom/x.png             119 x 127   px  a button, bind x
  bottom/y.png             119 x 126   px  a button, bind y
  bottom/a.png             119 x 126   px  a button, bind a
  bottom/b.png             119 x 126   px  a button, bind b
  bottom/select.png        162 x 60    px  a button, bind select
  bottom/start.png         162 x 60    px  a button, bind start
  side/background.png     2238 x 1080  px  the side page, behind everything
  side/frame.png          1338 x 590   px  the side page's bezel
  side/save.png            268 x 84    px  a quick action on the frame, bind quickSave
  side/load.png            267 x 84    px  a quick action on the frame, bind quickLoad
  side/turbo.png           268 x 84    px  a quick action on the frame, bind turbo
  side/fast-forward.png    267 x 84    px  a quick action on the frame, bind toggleFastForward
  side/screens.png         268 x 84    px  a quick action on the frame, bind screens
  side/l.png               372 x 123   px  a button, bind l
  side/r.png               372 x 123   px  a button, bind r
  side/menu.png            156 x 96    px  a button, bind menu
  side/dpad.png            362 x 374   px  the D-pad, bind dpad
  side/dpad-ball.png       265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  side/x.png               118 x 127   px  a button, bind x
  side/y.png               119 x 126   px  a button, bind y
  side/a.png               119 x 126   px  a button, bind a
  side/b.png               118 x 126   px  a button, bind b
  side/select.png          162 x 60    px  a button, bind select
  side/start.png           162 x 60    px  a button, bind start

tablet-portrait/  (1600 x 2560 px)
  game screen at 288, 52, 1024 x 768 px (left clear: nothing is drawn there)
  game screen at 288, 820, 1024 x 768 px (left clear: nothing is drawn there)
  top/ game screen at 52, 52, 1496 x 1122 px (its screen-layout page)
  bottom/ game screen at 52, 52, 1496 x 1122 px (its screen-layout page)
  side/ game screen at 52, 52, 748 x 561 px (its screen-layout page)
  side/ game screen at 800, 52, 748 x 561 px (its screen-layout page)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1064 x 1644  px  the bezel around the game screen
  save.png                 213 x 88    px  a quick action on the frame, bind quickSave
  load.png                 213 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                212 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         213 x 88    px  a quick action on the frame, bind toggleFastForward
  screens.png              213 x 88    px  a quick action on the frame, bind screens
  l.png                    340 x 102   px  a button, bind l
  r.png                    340 x 102   px  a button, bind r
  menu.png                 104 x 88    px  a button, bind menu
  dpad.png                 314 x 322   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    103 x 110   px  a button, bind x
  y.png                    103 x 109   px  a button, bind y
  a.png                    103 x 109   px  a button, bind a
  b.png                    103 x 110   px  a button, bind b
  select.png               132 x 48    px  a button, bind select
  start.png                132 x 48    px  a button, bind start
  top/background.png      1600 x 2560  px  the top page, behind everything
  top/frame.png           1536 x 1230  px  the top page's bezel
  top/save.png             307 x 88    px  a quick action on the frame, bind quickSave
  top/load.png             307 x 88    px  a quick action on the frame, bind quickLoad
  top/turbo.png            308 x 88    px  a quick action on the frame, bind turbo
  top/fast-forward.png     307 x 88    px  a quick action on the frame, bind toggleFastForward
  top/screens.png          307 x 88    px  a quick action on the frame, bind screens
  top/l.png                340 x 102   px  a button, bind l
  top/r.png                340 x 102   px  a button, bind r
  top/menu.png             104 x 88    px  a button, bind menu
  top/dpad.png             314 x 322   px  the D-pad, bind dpad
  top/dpad-ball.png        230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  top/x.png                103 x 110   px  a button, bind x
  top/y.png                103 x 110   px  a button, bind y
  top/a.png                103 x 110   px  a button, bind a
  top/b.png                103 x 110   px  a button, bind b
  top/select.png           132 x 48    px  a button, bind select
  top/start.png            132 x 48    px  a button, bind start
  bottom/background.png   1600 x 2560  px  the bottom page, behind everything
  bottom/frame.png        1536 x 1230  px  the bottom page's bezel
  bottom/save.png          307 x 88    px  a quick action on the frame, bind quickSave
  bottom/load.png          307 x 88    px  a quick action on the frame, bind quickLoad
  bottom/turbo.png         308 x 88    px  a quick action on the frame, bind turbo
  bottom/fast-forward.png   307 x 88    px  a quick action on the frame, bind toggleFastForward
  bottom/screens.png       307 x 88    px  a quick action on the frame, bind screens
  bottom/l.png             340 x 102   px  a button, bind l
  bottom/r.png             340 x 102   px  a button, bind r
  bottom/menu.png          104 x 88    px  a button, bind menu
  bottom/dpad.png          314 x 322   px  the D-pad, bind dpad
  bottom/dpad-ball.png     230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  bottom/x.png             103 x 110   px  a button, bind x
  bottom/y.png             103 x 110   px  a button, bind y
  bottom/a.png             103 x 110   px  a button, bind a
  bottom/b.png             103 x 110   px  a button, bind b
  bottom/select.png        132 x 48    px  a button, bind select
  bottom/start.png         132 x 48    px  a button, bind start
  side/background.png     1600 x 2560  px  the side page, behind everything
  side/frame.png          1536 x 669   px  the side page's bezel
  side/save.png            307 x 88    px  a quick action on the frame, bind quickSave
  side/load.png            307 x 88    px  a quick action on the frame, bind quickLoad
  side/turbo.png           308 x 88    px  a quick action on the frame, bind turbo
  side/fast-forward.png    307 x 88    px  a quick action on the frame, bind toggleFastForward
  side/screens.png         307 x 88    px  a quick action on the frame, bind screens
  side/l.png               340 x 102   px  a button, bind l
  side/r.png               340 x 102   px  a button, bind r
  side/menu.png            104 x 88    px  a button, bind menu
  side/dpad.png            314 x 321   px  the D-pad, bind dpad
  side/dpad-ball.png       230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  side/x.png               103 x 110   px  a button, bind x
  side/y.png               103 x 110   px  a button, bind y
  side/a.png               103 x 110   px  a button, bind a
  side/b.png               103 x 110   px  a button, bind b
  side/select.png          132 x 48    px  a button, bind select
  side/start.png           132 x 48    px  a button, bind start

tablet-landscape/  (2560 x 1600 px)
  game screen at 804, 52, 952 x 714 px (left clear: nothing is drawn there)
  game screen at 804, 766, 952 x 714 px (left clear: nothing is drawn there)
  top/ game screen at 500, 181, 1560 x 1170 px (its screen-layout page)
  bottom/ game screen at 500, 181, 1560 x 1170 px (its screen-layout page)
  side/ game screen at 500, 474, 780 x 585 px (its screen-layout page)
  side/ game screen at 1280, 474, 780 x 585 px (its screen-layout page)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png                992 x 1536  px  the bezel around the game screen
  save.png                 198 x 88    px  a quick action on the frame, bind quickSave
  load.png                 199 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                198 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         199 x 88    px  a quick action on the frame, bind toggleFastForward
  screens.png              198 x 88    px  a quick action on the frame, bind screens
  l.png                    340 x 102   px  a button, bind l
  r.png                    340 x 102   px  a button, bind r
  menu.png                 104 x 84    px  a button, bind menu
  dpad.png                 314 x 322   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    103 x 110   px  a button, bind x
  y.png                    103 x 110   px  a button, bind y
  a.png                    103 x 110   px  a button, bind a
  b.png                    103 x 110   px  a button, bind b
  select.png               132 x 48    px  a button, bind select
  start.png                132 x 48    px  a button, bind start
  top/background.png      2560 x 1600  px  the top page, behind everything
  top/frame.png           1600 x 1278  px  the top page's bezel
  top/save.png             320 x 88    px  a quick action on the frame, bind quickSave
  top/load.png             320 x 88    px  a quick action on the frame, bind quickLoad
  top/turbo.png            320 x 88    px  a quick action on the frame, bind turbo
  top/fast-forward.png     320 x 88    px  a quick action on the frame, bind toggleFastForward
  top/screens.png          320 x 88    px  a quick action on the frame, bind screens
  top/l.png                340 x 102   px  a button, bind l
  top/r.png                340 x 102   px  a button, bind r
  top/menu.png             104 x 84    px  a button, bind menu
  top/dpad.png             314 x 322   px  the D-pad, bind dpad
  top/dpad-ball.png        230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  top/x.png                103 x 110   px  a button, bind x
  top/y.png                103 x 110   px  a button, bind y
  top/a.png                103 x 110   px  a button, bind a
  top/b.png                103 x 110   px  a button, bind b
  top/select.png           132 x 48    px  a button, bind select
  top/start.png            132 x 48    px  a button, bind start
  bottom/background.png   2560 x 1600  px  the bottom page, behind everything
  bottom/frame.png        1600 x 1278  px  the bottom page's bezel
  bottom/save.png          320 x 88    px  a quick action on the frame, bind quickSave
  bottom/load.png          320 x 88    px  a quick action on the frame, bind quickLoad
  bottom/turbo.png         320 x 88    px  a quick action on the frame, bind turbo
  bottom/fast-forward.png   320 x 88    px  a quick action on the frame, bind toggleFastForward
  bottom/screens.png       320 x 88    px  a quick action on the frame, bind screens
  bottom/l.png             340 x 102   px  a button, bind l
  bottom/r.png             340 x 102   px  a button, bind r
  bottom/menu.png          104 x 84    px  a button, bind menu
  bottom/dpad.png          314 x 322   px  the D-pad, bind dpad
  bottom/dpad-ball.png     230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  bottom/x.png             103 x 110   px  a button, bind x
  bottom/y.png             103 x 110   px  a button, bind y
  bottom/a.png             103 x 110   px  a button, bind a
  bottom/b.png             103 x 110   px  a button, bind b
  bottom/select.png        132 x 48    px  a button, bind select
  bottom/start.png         132 x 48    px  a button, bind start
  side/background.png     2560 x 1600  px  the side page, behind everything
  side/frame.png          1600 x 693   px  the side page's bezel
  side/save.png            320 x 88    px  a quick action on the frame, bind quickSave
  side/load.png            320 x 88    px  a quick action on the frame, bind quickLoad
  side/turbo.png           320 x 88    px  a quick action on the frame, bind turbo
  side/fast-forward.png    320 x 88    px  a quick action on the frame, bind toggleFastForward
  side/screens.png         320 x 88    px  a quick action on the frame, bind screens
  side/l.png               340 x 102   px  a button, bind l
  side/r.png               340 x 102   px  a button, bind r
  side/menu.png            104 x 84    px  a button, bind menu
  side/dpad.png            314 x 322   px  the D-pad, bind dpad
  side/dpad-ball.png       230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  side/x.png               103 x 110   px  a button, bind x
  side/y.png               103 x 110   px  a button, bind y
  side/a.png               103 x 110   px  a button, bind a
  side/b.png               103 x 110   px  a button, bind b
  side/select.png          132 x 48    px  a button, bind select
  side/start.png           132 x 48    px  a button, bind start

fold-portrait/  (1812 x 2178 px)
  game screen at 543, 78, 726 x 545 px (left clear: nothing is drawn there)
  game screen at 543, 623, 726 x 544 px (left clear: nothing is drawn there)
  top/ game screen at 325, 78, 1162 x 871 px (its screen-layout page)
  bottom/ game screen at 325, 78, 1162 x 871 px (its screen-layout page)
  side/ game screen at 78, 78, 828 x 621 px (its screen-layout page)
  side/ game screen at 906, 78, 828 x 621 px (its screen-layout page)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png                786 x 1251  px  the bezel around the game screen
  save.png                 157 x 132   px  a quick action on the frame, bind quickSave
  load.png                 157 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                158 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         157 x 132   px  a quick action on the frame, bind toggleFastForward
  screens.png              157 x 132   px  a quick action on the frame, bind screens
  l.png                    510 x 153   px  a button, bind l
  r.png                    510 x 153   px  a button, bind r
  menu.png                 156 x 132   px  a button, bind menu
  dpad.png                 170 x 182   px  the D-pad, bind dpad
  dpad-ball.png            125 x 125   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                     56 x 60    px  a button, bind x
  y.png                     56 x 60    px  a button, bind y
  a.png                     56 x 60    px  a button, bind a
  b.png                     56 x 60    px  a button, bind b
  select.png               198 x 72    px  a button, bind select
  start.png                198 x 72    px  a button, bind start
  top/background.png      1812 x 2178  px  the top page, behind everything
  top/frame.png           1222 x 1033  px  the top page's bezel
  top/save.png             244 x 132   px  a quick action on the frame, bind quickSave
  top/load.png             245 x 132   px  a quick action on the frame, bind quickLoad
  top/turbo.png            244 x 132   px  a quick action on the frame, bind turbo
  top/fast-forward.png     245 x 132   px  a quick action on the frame, bind toggleFastForward
  top/screens.png          244 x 132   px  a quick action on the frame, bind screens
  top/l.png                510 x 153   px  a button, bind l
  top/r.png                510 x 153   px  a button, bind r
  top/menu.png             156 x 132   px  a button, bind menu
  top/dpad.png             350 x 362   px  the D-pad, bind dpad
  top/dpad-ball.png        257 x 257   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  top/x.png                115 x 122   px  a button, bind x
  top/y.png                115 x 123   px  a button, bind y
  top/a.png                115 x 123   px  a button, bind a
  top/b.png                115 x 122   px  a button, bind b
  top/select.png           198 x 72    px  a button, bind select
  top/start.png            198 x 72    px  a button, bind start
  bottom/background.png   1812 x 2178  px  the bottom page, behind everything
  bottom/frame.png        1222 x 1033  px  the bottom page's bezel
  bottom/save.png          244 x 132   px  a quick action on the frame, bind quickSave
  bottom/load.png          245 x 132   px  a quick action on the frame, bind quickLoad
  bottom/turbo.png         244 x 132   px  a quick action on the frame, bind turbo
  bottom/fast-forward.png   245 x 132   px  a quick action on the frame, bind toggleFastForward
  bottom/screens.png       244 x 132   px  a quick action on the frame, bind screens
  bottom/l.png             510 x 153   px  a button, bind l
  bottom/r.png             510 x 153   px  a button, bind r
  bottom/menu.png          156 x 132   px  a button, bind menu
  bottom/dpad.png          350 x 362   px  the D-pad, bind dpad
  bottom/dpad-ball.png     257 x 257   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  bottom/x.png             115 x 122   px  a button, bind x
  bottom/y.png             115 x 123   px  a button, bind y
  bottom/a.png             115 x 123   px  a button, bind a
  bottom/b.png             115 x 122   px  a button, bind b
  bottom/select.png        198 x 72    px  a button, bind select
  bottom/start.png         198 x 72    px  a button, bind start
  side/background.png     1812 x 2178  px  the side page, behind everything
  side/frame.png          1716 x 783   px  the side page's bezel
  side/save.png            343 x 132   px  a quick action on the frame, bind quickSave
  side/load.png            343 x 132   px  a quick action on the frame, bind quickLoad
  side/turbo.png           344 x 132   px  a quick action on the frame, bind turbo
  side/fast-forward.png    343 x 132   px  a quick action on the frame, bind toggleFastForward
  side/screens.png         343 x 132   px  a quick action on the frame, bind screens
  side/l.png               510 x 153   px  a button, bind l
  side/r.png               510 x 153   px  a button, bind r
  side/menu.png            156 x 132   px  a button, bind menu
  side/dpad.png            470 x 483   px  the D-pad, bind dpad
  side/dpad-ball.png       345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  side/x.png               154 x 165   px  a button, bind x
  side/y.png               154 x 165   px  a button, bind y
  side/a.png               154 x 165   px  a button, bind a
  side/b.png               154 x 165   px  a button, bind b
  side/select.png          198 x 72    px  a button, bind select
  side/start.png           198 x 72    px  a button, bind start

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 122, 978 x 733 px (left clear: nothing is drawn there)
  game screen at 600, 855, 978 x 734 px (left clear: nothing is drawn there)
  top/ game screen at 600, 488, 978 x 734 px (its screen-layout page)
  bottom/ game screen at 600, 488, 978 x 734 px (its screen-layout page)
  side/ game screen at 600, 672, 489 x 367 px (its screen-layout page)
  side/ game screen at 1089, 672, 489 x 367 px (its screen-layout page)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 1629  px  the bezel around the game screen
  save.png                 208 x 132   px  a quick action on the frame, bind quickSave
  load.png                 207 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                208 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         207 x 132   px  a quick action on the frame, bind toggleFastForward
  screens.png              208 x 132   px  a quick action on the frame, bind screens
  l.png                    498 x 153   px  a button, bind l
  r.png                    498 x 153   px  a button, bind r
  menu.png                 156 x 126   px  a button, bind menu
  dpad.png                 470 x 482   px  the D-pad, bind dpad
  dpad-ball.png            345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    154 x 165   px  a button, bind x
  y.png                    154 x 164   px  a button, bind y
  a.png                    154 x 164   px  a button, bind a
  b.png                    154 x 164   px  a button, bind b
  select.png               198 x 72    px  a button, bind select
  start.png                198 x 72    px  a button, bind start
  top/background.png      2178 x 1812  px  the top page, behind everything
  top/frame.png           1038 x 896   px  the top page's bezel
  top/save.png             208 x 132   px  a quick action on the frame, bind quickSave
  top/load.png             207 x 132   px  a quick action on the frame, bind quickLoad
  top/turbo.png            208 x 132   px  a quick action on the frame, bind turbo
  top/fast-forward.png     207 x 132   px  a quick action on the frame, bind toggleFastForward
  top/screens.png          208 x 132   px  a quick action on the frame, bind screens
  top/l.png                498 x 153   px  a button, bind l
  top/r.png                498 x 153   px  a button, bind r
  top/menu.png             156 x 126   px  a button, bind menu
  top/dpad.png             470 x 482   px  the D-pad, bind dpad
  top/dpad-ball.png        345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  top/x.png                154 x 165   px  a button, bind x
  top/y.png                154 x 164   px  a button, bind y
  top/a.png                154 x 164   px  a button, bind a
  top/b.png                154 x 164   px  a button, bind b
  top/select.png           198 x 72    px  a button, bind select
  top/start.png            198 x 72    px  a button, bind start
  bottom/background.png   2178 x 1812  px  the bottom page, behind everything
  bottom/frame.png        1038 x 896   px  the bottom page's bezel
  bottom/save.png          208 x 132   px  a quick action on the frame, bind quickSave
  bottom/load.png          207 x 132   px  a quick action on the frame, bind quickLoad
  bottom/turbo.png         208 x 132   px  a quick action on the frame, bind turbo
  bottom/fast-forward.png   207 x 132   px  a quick action on the frame, bind toggleFastForward
  bottom/screens.png       208 x 132   px  a quick action on the frame, bind screens
  bottom/l.png             498 x 153   px  a button, bind l
  bottom/r.png             498 x 153   px  a button, bind r
  bottom/menu.png          156 x 126   px  a button, bind menu
  bottom/dpad.png          470 x 482   px  the D-pad, bind dpad
  bottom/dpad-ball.png     345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  bottom/x.png             154 x 165   px  a button, bind x
  bottom/y.png             154 x 164   px  a button, bind y
  bottom/a.png             154 x 164   px  a button, bind a
  bottom/b.png             154 x 164   px  a button, bind b
  bottom/select.png        198 x 72    px  a button, bind select
  bottom/start.png         198 x 72    px  a button, bind start
  side/background.png     2178 x 1812  px  the side page, behind everything
  side/frame.png          1038 x 529   px  the side page's bezel
  side/save.png            208 x 132   px  a quick action on the frame, bind quickSave
  side/load.png            207 x 132   px  a quick action on the frame, bind quickLoad
  side/turbo.png           208 x 132   px  a quick action on the frame, bind turbo
  side/fast-forward.png    207 x 132   px  a quick action on the frame, bind toggleFastForward
  side/screens.png         208 x 132   px  a quick action on the frame, bind screens
  side/l.png               498 x 153   px  a button, bind l
  side/r.png               498 x 153   px  a button, bind r
  side/menu.png            156 x 126   px  a button, bind menu
  side/dpad.png            470 x 482   px  the D-pad, bind dpad
  side/dpad-ball.png       345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  side/x.png               154 x 165   px  a button, bind x
  side/y.png               154 x 164   px  a button, bind y
  side/a.png               154 x 164   px  a button, bind a
  side/b.png               154 x 164   px  a button, bind b
  side/select.png          198 x 72    px  a button, bind select
  side/start.png           198 x 72    px  a button, bind start

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, NDS-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/NDS/ on the device.
  3. Start a Nintendo DS game. Delete the folder to go back to the bundled skin.
