PSP skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 36, 36, 1008 x 571 px (left clear: nothing is drawn there)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png               1044 x 679   px  the bezel around the game screen
  save.png                 261 x 90    px  a quick action on the frame, bind quickSave
  load.png                 261 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                261 x 90    px  a quick action on the frame, bind turbo
  fast-forward.png         261 x 90    px  a quick action on the frame, bind toggleFastForward
  l.png                    372 x 120   px  a button, bind l
  r.png                    372 x 120   px  a button, bind r
  menu.png                 156 x 102   px  a button, bind menu
  dpad.png                 420 x 420   px  the D-pad, bind dpad
  dpad-ball.png            308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    138 x 138   px  a button, bind x
  y.png                    138 x 138   px  a button, bind y
  a.png                    138 x 138   px  a button, bind a
  b.png                    138 x 138   px  a button, bind b
  stick-base.png           276 x 276   px  the stick's well, bind analogStick
  stick-knob.png           138 x 138   px  the stick's knob, moved by the thumb, bind analogStick
  select.png               162 x 54    px  a button, bind select
  start.png                162 x 54    px  a button, bind start

phone-landscape/  (2238 x 1080 px)
  game screen at 468, 138, 1302 x 738 px (left clear: nothing is drawn there)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png               1338 x 840   px  the bezel around the game screen
  save.png                 335 x 84    px  a quick action on the frame, bind quickSave
  load.png                 334 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                335 x 84    px  a quick action on the frame, bind turbo
  fast-forward.png         334 x 84    px  a quick action on the frame, bind toggleFastForward
  l.png                    372 x 114   px  a button, bind l
  r.png                    372 x 114   px  a button, bind r
  menu.png                 156 x 90    px  a button, bind menu
  dpad.png                 318 x 318   px  the D-pad, bind dpad
  dpad-ball.png            233 x 233   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    104 x 105   px  a button, bind x
  y.png                    104 x 104   px  a button, bind y
  a.png                    104 x 104   px  a button, bind a
  b.png                    104 x 105   px  a button, bind b
  stick-base.png           208 x 209   px  the stick's well, bind analogStick
  stick-knob.png           104 x 104   px  the stick's knob, moved by the thumb, bind analogStick
  select.png               162 x 54    px  a button, bind select
  start.png                162 x 54    px  a button, bind start

tablet-portrait/  (1600 x 2560 px)
  game screen at 52, 52, 1496 x 848 px (left clear: nothing is drawn there)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1536 x 956   px  the bezel around the game screen
  save.png                 384 x 88    px  a quick action on the frame, bind quickSave
  load.png                 384 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                384 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         384 x 88    px  a quick action on the frame, bind toggleFastForward
  l.png                    340 x 96    px  a button, bind l
  r.png                    340 x 96    px  a button, bind r
  menu.png                 104 x 84    px  a button, bind menu
  dpad.png                 314 x 313   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    103 x 103   px  a button, bind x
  y.png                    103 x 103   px  a button, bind y
  a.png                    103 x 103   px  a button, bind a
  b.png                    103 x 103   px  a button, bind b
  stick-base.png           206 x 206   px  the stick's well, bind analogStick
  stick-knob.png           103 x 103   px  the stick's knob, moved by the thumb, bind analogStick
  select.png               132 x 44    px  a button, bind select
  start.png                132 x 44    px  a button, bind start

tablet-landscape/  (2560 x 1600 px)
  game screen at 500, 324, 1560 x 884 px (left clear: nothing is drawn there)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png               1600 x 992   px  the bezel around the game screen
  save.png                 400 x 88    px  a quick action on the frame, bind quickSave
  load.png                 400 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                400 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         400 x 88    px  a quick action on the frame, bind toggleFastForward
  l.png                    340 x 96    px  a button, bind l
  r.png                    340 x 96    px  a button, bind r
  menu.png                 104 x 80    px  a button, bind menu
  dpad.png                 314 x 313   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    103 x 103   px  a button, bind x
  y.png                    103 x 103   px  a button, bind y
  a.png                    103 x 103   px  a button, bind a
  b.png                    103 x 103   px  a button, bind b
  stick-base.png           206 x 206   px  the stick's well, bind analogStick
  stick-knob.png           103 x 103   px  the stick's knob, moved by the thumb, bind analogStick
  select.png               132 x 44    px  a button, bind select
  start.png                132 x 44    px  a button, bind start

fold-portrait/  (1812 x 2178 px)
  game screen at 137, 78, 1538 x 871 px (left clear: nothing is drawn there)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png               1598 x 1033  px  the bezel around the game screen
  save.png                 400 x 132   px  a quick action on the frame, bind quickSave
  load.png                 399 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                399 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         400 x 132   px  a quick action on the frame, bind toggleFastForward
  l.png                    510 x 144   px  a button, bind l
  r.png                    510 x 144   px  a button, bind r
  menu.png                 156 x 126   px  a button, bind menu
  dpad.png                 206 x 205   px  the D-pad, bind dpad
  dpad-ball.png            150 x 150   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                     68 x 67    px  a button, bind x
  y.png                     68 x 68    px  a button, bind y
  a.png                     68 x 68    px  a button, bind a
  b.png                     68 x 68    px  a button, bind b
  stick-base.png           134 x 135   px  the stick's well, bind analogStick
  stick-knob.png            67 x 67    px  the stick's knob, moved by the thumb, bind analogStick
  select.png               198 x 66    px  a button, bind select
  start.png                198 x 66    px  a button, bind start

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 578, 978 x 554 px (left clear: nothing is drawn there)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 716   px  the bezel around the game screen
  save.png                 260 x 132   px  a quick action on the frame, bind quickSave
  load.png                 259 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                260 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         259 x 132   px  a quick action on the frame, bind toggleFastForward
  l.png                    498 x 144   px  a button, bind l
  r.png                    498 x 144   px  a button, bind r
  menu.png                 156 x 120   px  a button, bind menu
  dpad.png                 470 x 470   px  the D-pad, bind dpad
  dpad-ball.png            345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    154 x 154   px  a button, bind x
  y.png                    154 x 154   px  a button, bind y
  a.png                    154 x 154   px  a button, bind a
  b.png                    154 x 154   px  a button, bind b
  stick-base.png           309 x 309   px  the stick's well, bind analogStick
  stick-knob.png           155 x 155   px  the stick's knob, moved by the thumb, bind analogStick
  select.png               198 x 66    px  a button, bind select
  start.png                198 x 66    px  a button, bind start

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, PSP-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/PSP/ on the device.
  3. Start a PSP game. Delete the folder to go back to the bundled skin.
