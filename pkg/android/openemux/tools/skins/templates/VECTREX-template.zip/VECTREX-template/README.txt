Vectrex skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 162, 36, 756 x 940 px (left clear: nothing is drawn there)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png                792 x 1048  px  the bezel around the game screen
  save.png                 198 x 90    px  a quick action on the frame, bind quickSave
  load.png                 198 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                198 x 90    px  a quick action on the frame, bind turbo
  fast-forward.png         198 x 90    px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 108   px  a button, bind menu
  dpad.png                 420 x 432   px  the D-pad, bind dpad
  dpad-ball.png            308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  a.png                    134 x 143   px  a button, bind a
  b.png                    135 x 143   px  a button, bind b
  x.png                    135 x 143   px  a button, bind x
  y.png                    134 x 143   px  a button, bind y

phone-landscape/  (2238 x 1080 px)
  game screen at 740, 36, 758 x 942 px (left clear: nothing is drawn there)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png                794 x 1044  px  the bezel around the game screen
  save.png                 198 x 84    px  a quick action on the frame, bind quickSave
  load.png                 199 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                199 x 84    px  a quick action on the frame, bind turbo
  fast-forward.png         198 x 84    px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 96    px  a button, bind menu
  dpad.png                 362 x 374   px  the D-pad, bind dpad
  dpad-ball.png            265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  a.png                    129 x 136   px  a button, bind a
  b.png                    129 x 136   px  a button, bind b
  x.png                    129 x 136   px  a button, bind x
  y.png                    129 x 136   px  a button, bind y

tablet-portrait/  (1600 x 2560 px)
  game screen at 285, 52, 1030 x 1280 px (left clear: nothing is drawn there)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1070 x 1388  px  the bezel around the game screen
  save.png                 267 x 88    px  a quick action on the frame, bind quickSave
  load.png                 268 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                268 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         267 x 88    px  a quick action on the frame, bind toggleFastForward
  menu.png                 104 x 88    px  a button, bind menu
  dpad.png                 314 x 321   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  a.png                    112 x 118   px  a button, bind a
  b.png                    112 x 118   px  a button, bind b
  x.png                    112 x 118   px  a button, bind x
  y.png                    112 x 118   px  a button, bind y

tablet-landscape/  (2560 x 1600 px)
  game screen at 705, 52, 1150 x 1428 px (left clear: nothing is drawn there)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png               1190 x 1536  px  the bezel around the game screen
  save.png                 298 x 88    px  a quick action on the frame, bind quickSave
  load.png                 297 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                297 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         298 x 88    px  a quick action on the frame, bind toggleFastForward
  menu.png                 104 x 84    px  a button, bind menu
  dpad.png                 313 x 322   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  a.png                    112 x 119   px  a button, bind a
  b.png                    112 x 119   px  a button, bind b
  x.png                    112 x 119   px  a button, bind x
  y.png                    112 x 119   px  a button, bind y

fold-portrait/  (1812 x 2178 px)
  game screen at 555, 78, 701 x 871 px (left clear: nothing is drawn there)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png                761 x 1033  px  the bezel around the game screen
  save.png                 191 x 132   px  a quick action on the frame, bind quickSave
  load.png                 190 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                190 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         191 x 132   px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 132   px  a button, bind menu
  dpad.png                 350 x 362   px  the D-pad, bind dpad
  dpad-ball.png            257 x 257   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  a.png                    125 x 132   px  a button, bind a
  b.png                    125 x 132   px  a button, bind b
  x.png                    125 x 132   px  a button, bind x
  y.png                    125 x 132   px  a button, bind y

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 248, 978 x 1215 px (left clear: nothing is drawn there)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 1377  px  the bezel around the game screen
  save.png                 260 x 132   px  a quick action on the frame, bind quickSave
  load.png                 259 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                260 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         259 x 132   px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 126   px  a button, bind menu
  dpad.png                 470 x 482   px  the D-pad, bind dpad
  dpad-ball.png            345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  a.png                    123 x 130   px  a button, bind a
  b.png                    123 x 130   px  a button, bind b
  x.png                    123 x 130   px  a button, bind x
  y.png                    123 x 130   px  a button, bind y

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, VECTREX-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/VECTREX/ on the device.
  3. Start a Vectrex game. Delete the folder to go back to the bundled skin.
