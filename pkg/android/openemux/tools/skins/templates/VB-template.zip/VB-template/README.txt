Virtual Boy skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 36, 36, 1008 x 588 px (left clear: nothing is drawn there)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png               1044 x 696   px  the bezel around the game screen
  save.png                 261 x 90    px  a quick action on the frame, bind quickSave
  load.png                 261 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                261 x 90    px  a quick action on the frame, bind turbo
  fast-forward.png         261 x 90    px  a quick action on the frame, bind toggleFastForward
  l.png                    372 x 129   px  a button, bind l
  r.png                    372 x 129   px  a button, bind r
  menu.png                 156 x 108   px  a button, bind menu
  dpad.png                 420 x 432   px  the D-pad, bind dpad
  dpad-ball.png            308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    186 x 195   px  a button, bind b
  a.png                    186 x 195   px  a button, bind a
  dpad2.png                420 x 432   px  the D-pad, bind dpad2
  dpad2-ball.png           308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad2
  select.png               162 x 60    px  a button, bind select
  start.png                162 x 60    px  a button, bind start

phone-landscape/  (2238 x 1080 px)
  game screen at 468, 127, 1302 x 760 px (left clear: nothing is drawn there)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png               1338 x 862   px  the bezel around the game screen
  save.png                 335 x 84    px  a quick action on the frame, bind quickSave
  load.png                 334 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                335 x 84    px  a quick action on the frame, bind turbo
  fast-forward.png         334 x 84    px  a quick action on the frame, bind toggleFastForward
  l.png                    372 x 123   px  a button, bind l
  r.png                    372 x 123   px  a button, bind r
  menu.png                 156 x 96    px  a button, bind menu
  dpad.png                 318 x 330   px  the D-pad, bind dpad
  dpad-ball.png            233 x 233   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    141 x 148   px  a button, bind b
  a.png                    141 x 147   px  a button, bind a
  dpad2.png                318 x 330   px  the D-pad, bind dpad2
  dpad2-ball.png           233 x 233   px  the D-pad's ball, moved by the thumb over the pad, bind dpad2
  select.png               162 x 60    px  a button, bind select
  start.png                162 x 60    px  a button, bind start

tablet-portrait/  (1600 x 2560 px)
  game screen at 52, 52, 1496 x 873 px (left clear: nothing is drawn there)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1536 x 981   px  the bezel around the game screen
  save.png                 384 x 88    px  a quick action on the frame, bind quickSave
  load.png                 384 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                384 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         384 x 88    px  a quick action on the frame, bind toggleFastForward
  l.png                    340 x 102   px  a button, bind l
  r.png                    340 x 102   px  a button, bind r
  menu.png                 104 x 88    px  a button, bind menu
  dpad.png                 314 x 321   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    139 x 146   px  a button, bind b
  a.png                    139 x 146   px  a button, bind a
  dpad2.png                314 x 321   px  the D-pad, bind dpad2
  dpad2-ball.png           230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad2
  select.png               132 x 48    px  a button, bind select
  start.png                132 x 48    px  a button, bind start

tablet-landscape/  (2560 x 1600 px)
  game screen at 500, 311, 1560 x 910 px (left clear: nothing is drawn there)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png               1600 x 1018  px  the bezel around the game screen
  save.png                 400 x 88    px  a quick action on the frame, bind quickSave
  load.png                 400 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                400 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         400 x 88    px  a quick action on the frame, bind toggleFastForward
  l.png                    340 x 102   px  a button, bind l
  r.png                    340 x 102   px  a button, bind r
  menu.png                 104 x 84    px  a button, bind menu
  dpad.png                 314 x 321   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    139 x 146   px  a button, bind b
  a.png                    139 x 145   px  a button, bind a
  dpad2.png                314 x 321   px  the D-pad, bind dpad2
  dpad2-ball.png           230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad2
  select.png               132 x 48    px  a button, bind select
  start.png                132 x 48    px  a button, bind start

fold-portrait/  (1812 x 2178 px)
  game screen at 159, 78, 1494 x 871 px (left clear: nothing is drawn there)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png               1554 x 1033  px  the bezel around the game screen
  save.png                 389 x 132   px  a quick action on the frame, bind quickSave
  load.png                 388 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                389 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         388 x 132   px  a quick action on the frame, bind toggleFastForward
  l.png                    510 x 153   px  a button, bind l
  r.png                    510 x 153   px  a button, bind r
  menu.png                 156 x 132   px  a button, bind menu
  dpad.png                 206 x 217   px  the D-pad, bind dpad
  dpad-ball.png            151 x 151   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                     91 x 95    px  a button, bind b
  a.png                     91 x 95    px  a button, bind a
  dpad2.png                206 x 217   px  the D-pad, bind dpad2
  dpad2-ball.png           151 x 151   px  the D-pad's ball, moved by the thumb over the pad, bind dpad2
  select.png               198 x 72    px  a button, bind select
  start.png                198 x 72    px  a button, bind start

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 570, 978 x 570 px (left clear: nothing is drawn there)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 732   px  the bezel around the game screen
  save.png                 260 x 132   px  a quick action on the frame, bind quickSave
  load.png                 259 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                260 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         259 x 132   px  a quick action on the frame, bind toggleFastForward
  l.png                    498 x 153   px  a button, bind l
  r.png                    498 x 153   px  a button, bind r
  menu.png                 156 x 126   px  a button, bind menu
  dpad.png                 470 x 482   px  the D-pad, bind dpad
  dpad-ball.png            345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    208 x 218   px  a button, bind b
  a.png                    208 x 218   px  a button, bind a
  dpad2.png                470 x 482   px  the D-pad, bind dpad2
  dpad2-ball.png           345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad2
  select.png               198 x 72    px  a button, bind select
  start.png                198 x 72    px  a button, bind start

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, VB-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/VB/ on the device.
  3. Start a Virtual Boy game. Delete the folder to go back to the bundled skin.
