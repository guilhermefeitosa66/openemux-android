Lynx skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 36, 36, 1008 x 643 px (left clear: nothing is drawn there)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png               1044 x 751   px  the bezel around the game screen
  save.png                 261 x 90    px  a quick action on the frame, bind quickSave
  load.png                 261 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                261 x 90    px  a quick action on the frame, bind turbo
  fast-forward.png         261 x 90    px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 102   px  a button, bind menu
  dpad.png                 420 x 420   px  the D-pad, bind dpad
  dpad-ball.png            308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    186 x 186   px  a button, bind b
  a.png                    186 x 186   px  a button, bind a
  option1.png              162 x 54    px  a button, bind option1
  option2.png              162 x 54    px  a button, bind option2
  start.png                162 x 54    px  a button, bind start

phone-landscape/  (2238 x 1080 px)
  game screen at 468, 92, 1302 x 830 px (left clear: nothing is drawn there)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png               1338 x 932   px  the bezel around the game screen
  save.png                 335 x 84    px  a quick action on the frame, bind quickSave
  load.png                 334 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                335 x 84    px  a quick action on the frame, bind turbo
  fast-forward.png         334 x 84    px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 90    px  a button, bind menu
  dpad.png                 362 x 362   px  the D-pad, bind dpad
  dpad-ball.png            265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    160 x 160   px  a button, bind b
  a.png                    160 x 160   px  a button, bind a
  option1.png              162 x 54    px  a button, bind option1
  option2.png              162 x 54    px  a button, bind option2
  start.png                162 x 54    px  a button, bind start

tablet-portrait/  (1600 x 2560 px)
  game screen at 52, 52, 1496 x 954 px (left clear: nothing is drawn there)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1536 x 1062  px  the bezel around the game screen
  save.png                 384 x 88    px  a quick action on the frame, bind quickSave
  load.png                 384 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                384 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         384 x 88    px  a quick action on the frame, bind toggleFastForward
  menu.png                 104 x 84    px  a button, bind menu
  dpad.png                 314 x 313   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    139 x 139   px  a button, bind b
  a.png                    139 x 138   px  a button, bind a
  option1.png              132 x 44    px  a button, bind option1
  option2.png              132 x 44    px  a button, bind option2
  start.png                132 x 44    px  a button, bind start

tablet-landscape/  (2560 x 1600 px)
  game screen at 500, 269, 1560 x 994 px (left clear: nothing is drawn there)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png               1600 x 1102  px  the bezel around the game screen
  save.png                 400 x 88    px  a quick action on the frame, bind quickSave
  load.png                 400 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                400 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         400 x 88    px  a quick action on the frame, bind toggleFastForward
  menu.png                 104 x 80    px  a button, bind menu
  dpad.png                 314 x 314   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    139 x 139   px  a button, bind b
  a.png                    139 x 139   px  a button, bind a
  option1.png              132 x 44    px  a button, bind option1
  option2.png              132 x 44    px  a button, bind option2
  start.png                132 x 44    px  a button, bind start

fold-portrait/  (1812 x 2178 px)
  game screen at 223, 78, 1366 x 871 px (left clear: nothing is drawn there)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png               1426 x 1033  px  the bezel around the game screen
  save.png                 356 x 132   px  a quick action on the frame, bind quickSave
  load.png                 357 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                357 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         356 x 132   px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 126   px  a button, bind menu
  dpad.png                 350 x 350   px  the D-pad, bind dpad
  dpad-ball.png            257 x 257   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    154 x 155   px  a button, bind b
  a.png                    154 x 155   px  a button, bind a
  option1.png              198 x 66    px  a button, bind option1
  option2.png              198 x 66    px  a button, bind option2
  start.png                198 x 66    px  a button, bind start

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 543, 978 x 624 px (left clear: nothing is drawn there)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 786   px  the bezel around the game screen
  save.png                 260 x 132   px  a quick action on the frame, bind quickSave
  load.png                 259 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                260 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         259 x 132   px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 120   px  a button, bind menu
  dpad.png                 470 x 470   px  the D-pad, bind dpad
  dpad-ball.png            345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    208 x 208   px  a button, bind b
  a.png                    208 x 209   px  a button, bind a
  option1.png              198 x 66    px  a button, bind option1
  option2.png              198 x 66    px  a button, bind option2
  start.png                198 x 66    px  a button, bind start

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, LYNX-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/LYNX/ on the device.
  3. Start a Lynx game. Delete the folder to go back to the bundled skin.
