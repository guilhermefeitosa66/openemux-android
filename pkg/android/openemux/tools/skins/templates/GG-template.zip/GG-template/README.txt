Game Gear skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 36, 36, 1008 x 907 px (left clear: nothing is drawn there)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png               1044 x 1015  px  the bezel around the game screen
  save.png                 261 x 90    px  a quick action on the frame, bind quickSave
  load.png                 261 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                261 x 90    px  a quick action on the frame, bind turbo
  fast-forward.png         261 x 90    px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 108   px  a button, bind menu
  dpad.png                 420 x 432   px  the D-pad, bind dpad
  dpad-ball.png            308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    186 x 195   px  a button, bind b
  a.png                    186 x 195   px  a button, bind a
  start.png                162 x 60    px  a button, bind start

phone-landscape/  (2238 x 1080 px)
  game screen at 596, 36, 1047 x 942 px (left clear: nothing is drawn there)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png               1083 x 1044  px  the bezel around the game screen
  save.png                 270 x 84    px  a quick action on the frame, bind quickSave
  load.png                 271 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                271 x 84    px  a quick action on the frame, bind turbo
  fast-forward.png         270 x 84    px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 96    px  a button, bind menu
  dpad.png                 362 x 374   px  the D-pad, bind dpad
  dpad-ball.png            265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    160 x 168   px  a button, bind b
  a.png                    160 x 167   px  a button, bind a
  start.png                162 x 60    px  a button, bind start

tablet-portrait/  (1600 x 2560 px)
  game screen at 89, 52, 1422 x 1280 px (left clear: nothing is drawn there)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1462 x 1388  px  the bezel around the game screen
  save.png                 365 x 88    px  a quick action on the frame, bind quickSave
  load.png                 366 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                366 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         365 x 88    px  a quick action on the frame, bind toggleFastForward
  menu.png                 104 x 88    px  a button, bind menu
  dpad.png                 314 x 321   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    139 x 145   px  a button, bind b
  a.png                    139 x 145   px  a button, bind a
  start.png                132 x 48    px  a button, bind start

tablet-landscape/  (2560 x 1600 px)
  game screen at 500, 64, 1560 x 1404 px (left clear: nothing is drawn there)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png               1600 x 1512  px  the bezel around the game screen
  save.png                 400 x 88    px  a quick action on the frame, bind quickSave
  load.png                 400 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                400 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         400 x 88    px  a quick action on the frame, bind toggleFastForward
  menu.png                 104 x 84    px  a button, bind menu
  dpad.png                 314 x 322   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    139 x 145   px  a button, bind b
  a.png                    139 x 146   px  a button, bind a
  start.png                132 x 48    px  a button, bind start

fold-portrait/  (1812 x 2178 px)
  game screen at 422, 78, 968 x 871 px (left clear: nothing is drawn there)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png               1028 x 1033  px  the bezel around the game screen
  save.png                 257 x 132   px  a quick action on the frame, bind quickSave
  load.png                 257 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                257 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         257 x 132   px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 132   px  a button, bind menu
  dpad.png                 350 x 362   px  the D-pad, bind dpad
  dpad-ball.png            257 x 257   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    154 x 162   px  a button, bind b
  a.png                    154 x 163   px  a button, bind a
  start.png                198 x 72    px  a button, bind start

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 415, 978 x 880 px (left clear: nothing is drawn there)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 1042  px  the bezel around the game screen
  save.png                 260 x 132   px  a quick action on the frame, bind quickSave
  load.png                 259 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                260 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         259 x 132   px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 126   px  a button, bind menu
  dpad.png                 470 x 482   px  the D-pad, bind dpad
  dpad-ball.png            345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    208 x 219   px  a button, bind b
  a.png                    208 x 219   px  a button, bind a
  start.png                198 x 72    px  a button, bind start

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, GG-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/GG/ on the device.
  3. Start a Game Gear game. Delete the folder to go back to the bundled skin.
