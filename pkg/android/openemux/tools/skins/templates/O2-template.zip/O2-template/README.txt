Odyssey² skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 36, 36, 1008 x 756 px (left clear: nothing is drawn there)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png               1044 x 864   px  the bezel around the game screen
  save.png                 261 x 90    px  a quick action on the frame, bind quickSave
  load.png                 261 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                261 x 90    px  a quick action on the frame, bind turbo
  fast-forward.png         261 x 90    px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 108   px  a button, bind menu
  dpad.png                 420 x 432   px  the D-pad, bind dpad
  dpad-ball.png            308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    252 x 261   px  a button, bind b
  keypad-toggle.png        162 x 60    px  a button, bind keypadToggle
  keypad/background.png   1080 x 2238  px  the keypad page, behind everything
  keypad/save.png          261 x 90    px  a quick action on the frame, bind quickSave
  keypad/load.png          261 x 90    px  a quick action on the frame, bind quickLoad
  keypad/turbo.png         261 x 90    px  a quick action on the frame, bind turbo
  keypad/fast-forward.png   261 x 90    px  a quick action on the frame, bind toggleFastForward
  keypad/menu.png          156 x 108   px  a button, bind menu
  keypad/dpad.png          420 x 432   px  the D-pad, bind dpad
  keypad/dpad-ball.png     308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  keypad/key-1.png         170 x 154   px  a keypad key, bind keypad1
  keypad/key-2.png         170 x 154   px  a keypad key, bind keypad2
  keypad/key-3.png         170 x 154   px  a keypad key, bind keypad3
  keypad/key-4.png         170 x 153   px  a keypad key, bind keypad4
  keypad/key-5.png         170 x 153   px  a keypad key, bind keypad5
  keypad/key-6.png         170 x 153   px  a keypad key, bind keypad6
  keypad/key-7.png         170 x 154   px  a keypad key, bind keypad7
  keypad/key-8.png         170 x 154   px  a keypad key, bind keypad8
  keypad/key-9.png         170 x 154   px  a keypad key, bind keypad9
  keypad/key-star.png      170 x 154   px  a keypad key, bind keypadStar
  keypad/key-0.png         170 x 154   px  a keypad key, bind keypad0
  keypad/key-hash.png      170 x 154   px  a keypad key, bind keypadHash
  keypad/keypad-toggle.png   162 x 60    px  a button, bind keypadToggle

phone-landscape/  (2238 x 1080 px)
  game screen at 491, 36, 1256 x 942 px (left clear: nothing is drawn there)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png               1292 x 1044  px  the bezel around the game screen
  save.png                 323 x 84    px  a quick action on the frame, bind quickSave
  load.png                 323 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                323 x 84    px  a quick action on the frame, bind turbo
  fast-forward.png         323 x 84    px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 96    px  a button, bind menu
  dpad.png                 361 x 374   px  the D-pad, bind dpad
  dpad-ball.png            265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    217 x 224   px  a button, bind b
  keypad-toggle.png        162 x 60    px  a button, bind keypadToggle
  keypad/background.png   2238 x 1080  px  the keypad page, behind everything
  keypad/save.png          323 x 84    px  a quick action on the frame, bind quickSave
  keypad/load.png          323 x 84    px  a quick action on the frame, bind quickLoad
  keypad/turbo.png         323 x 84    px  a quick action on the frame, bind turbo
  keypad/fast-forward.png   323 x 84    px  a quick action on the frame, bind toggleFastForward
  keypad/menu.png          156 x 96    px  a button, bind menu
  keypad/dpad.png          361 x 374   px  the D-pad, bind dpad
  keypad/dpad-ball.png     265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  keypad/key-1.png         130 x 118   px  a keypad key, bind keypad1
  keypad/key-2.png         129 x 118   px  a keypad key, bind keypad2
  keypad/key-3.png         130 x 118   px  a keypad key, bind keypad3
  keypad/key-4.png         130 x 118   px  a keypad key, bind keypad4
  keypad/key-5.png         129 x 118   px  a keypad key, bind keypad5
  keypad/key-6.png         130 x 118   px  a keypad key, bind keypad6
  keypad/key-7.png         130 x 118   px  a keypad key, bind keypad7
  keypad/key-8.png         129 x 118   px  a keypad key, bind keypad8
  keypad/key-9.png         130 x 118   px  a keypad key, bind keypad9
  keypad/key-star.png      130 x 117   px  a keypad key, bind keypadStar
  keypad/key-0.png         129 x 117   px  a keypad key, bind keypad0
  keypad/key-hash.png      130 x 117   px  a keypad key, bind keypadHash
  keypad/keypad-toggle.png   162 x 60    px  a button, bind keypadToggle

tablet-portrait/  (1600 x 2560 px)
  game screen at 52, 52, 1496 x 1122 px (left clear: nothing is drawn there)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1536 x 1230  px  the bezel around the game screen
  save.png                 384 x 88    px  a quick action on the frame, bind quickSave
  load.png                 384 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                384 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         384 x 88    px  a quick action on the frame, bind toggleFastForward
  menu.png                 104 x 88    px  a button, bind menu
  dpad.png                 314 x 322   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    188 x 195   px  a button, bind b
  keypad-toggle.png        132 x 48    px  a button, bind keypadToggle
  keypad/background.png   1600 x 2560  px  the keypad page, behind everything
  keypad/save.png          384 x 88    px  a quick action on the frame, bind quickSave
  keypad/load.png          384 x 88    px  a quick action on the frame, bind quickLoad
  keypad/turbo.png         384 x 88    px  a quick action on the frame, bind turbo
  keypad/fast-forward.png   384 x 88    px  a quick action on the frame, bind toggleFastForward
  keypad/menu.png          104 x 88    px  a button, bind menu
  keypad/dpad.png          314 x 322   px  the D-pad, bind dpad
  keypad/dpad-ball.png     230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  keypad/key-1.png         168 x 152   px  a keypad key, bind keypad1
  keypad/key-2.png         168 x 152   px  a keypad key, bind keypad2
  keypad/key-3.png         168 x 152   px  a keypad key, bind keypad3
  keypad/key-4.png         168 x 152   px  a keypad key, bind keypad4
  keypad/key-5.png         168 x 152   px  a keypad key, bind keypad5
  keypad/key-6.png         168 x 152   px  a keypad key, bind keypad6
  keypad/key-7.png         168 x 152   px  a keypad key, bind keypad7
  keypad/key-8.png         168 x 152   px  a keypad key, bind keypad8
  keypad/key-9.png         168 x 152   px  a keypad key, bind keypad9
  keypad/key-star.png      168 x 153   px  a keypad key, bind keypadStar
  keypad/key-0.png         168 x 153   px  a keypad key, bind keypad0
  keypad/key-hash.png      168 x 153   px  a keypad key, bind keypadHash
  keypad/keypad-toggle.png   132 x 48    px  a button, bind keypadToggle

tablet-landscape/  (2560 x 1600 px)
  game screen at 500, 181, 1560 x 1170 px (left clear: nothing is drawn there)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png               1600 x 1278  px  the bezel around the game screen
  save.png                 400 x 88    px  a quick action on the frame, bind quickSave
  load.png                 400 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                400 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         400 x 88    px  a quick action on the frame, bind toggleFastForward
  menu.png                 104 x 84    px  a button, bind menu
  dpad.png                 314 x 322   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    188 x 195   px  a button, bind b
  keypad-toggle.png        132 x 48    px  a button, bind keypadToggle
  keypad/background.png   2560 x 1600  px  the keypad page, behind everything
  keypad/save.png          400 x 88    px  a quick action on the frame, bind quickSave
  keypad/load.png          400 x 88    px  a quick action on the frame, bind quickLoad
  keypad/turbo.png         400 x 88    px  a quick action on the frame, bind turbo
  keypad/fast-forward.png   400 x 88    px  a quick action on the frame, bind toggleFastForward
  keypad/menu.png          104 x 84    px  a button, bind menu
  keypad/dpad.png          314 x 322   px  the D-pad, bind dpad
  keypad/dpad-ball.png     230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  keypad/key-1.png         136 x 123   px  a keypad key, bind keypad1
  keypad/key-2.png         136 x 123   px  a keypad key, bind keypad2
  keypad/key-3.png         136 x 123   px  a keypad key, bind keypad3
  keypad/key-4.png         136 x 123   px  a keypad key, bind keypad4
  keypad/key-5.png         136 x 123   px  a keypad key, bind keypad5
  keypad/key-6.png         136 x 123   px  a keypad key, bind keypad6
  keypad/key-7.png         136 x 123   px  a keypad key, bind keypad7
  keypad/key-8.png         136 x 123   px  a keypad key, bind keypad8
  keypad/key-9.png         136 x 123   px  a keypad key, bind keypad9
  keypad/key-star.png      136 x 123   px  a keypad key, bind keypadStar
  keypad/key-0.png         136 x 123   px  a keypad key, bind keypad0
  keypad/key-hash.png      136 x 123   px  a keypad key, bind keypadHash
  keypad/keypad-toggle.png   132 x 48    px  a button, bind keypadToggle

fold-portrait/  (1812 x 2178 px)
  game screen at 325, 78, 1162 x 871 px (left clear: nothing is drawn there)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png               1222 x 1033  px  the bezel around the game screen
  save.png                 306 x 132   px  a quick action on the frame, bind quickSave
  load.png                 305 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                305 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         306 x 132   px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 132   px  a button, bind menu
  dpad.png                 350 x 362   px  the D-pad, bind dpad
  dpad-ball.png            257 x 257   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    210 x 217   px  a button, bind b
  keypad-toggle.png        198 x 72    px  a button, bind keypadToggle
  keypad/background.png   1812 x 2178  px  the keypad page, behind everything
  keypad/save.png          306 x 132   px  a quick action on the frame, bind quickSave
  keypad/load.png          305 x 132   px  a quick action on the frame, bind quickLoad
  keypad/turbo.png         305 x 132   px  a quick action on the frame, bind turbo
  keypad/fast-forward.png   306 x 132   px  a quick action on the frame, bind toggleFastForward
  keypad/menu.png          156 x 132   px  a button, bind menu
  keypad/dpad.png          350 x 362   px  the D-pad, bind dpad
  keypad/dpad-ball.png     257 x 257   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  keypad/key-1.png         252 x 88    px  a keypad key, bind keypad1
  keypad/key-2.png         252 x 88    px  a keypad key, bind keypad2
  keypad/key-3.png         252 x 88    px  a keypad key, bind keypad3
  keypad/key-4.png         252 x 88    px  a keypad key, bind keypad4
  keypad/key-5.png         252 x 88    px  a keypad key, bind keypad5
  keypad/key-6.png         252 x 88    px  a keypad key, bind keypad6
  keypad/key-7.png         252 x 88    px  a keypad key, bind keypad7
  keypad/key-8.png         252 x 88    px  a keypad key, bind keypad8
  keypad/key-9.png         252 x 88    px  a keypad key, bind keypad9
  keypad/key-star.png      252 x 89    px  a keypad key, bind keypadStar
  keypad/key-0.png         252 x 89    px  a keypad key, bind keypad0
  keypad/key-hash.png      252 x 89    px  a keypad key, bind keypadHash
  keypad/keypad-toggle.png   198 x 72    px  a button, bind keypadToggle

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 488, 978 x 734 px (left clear: nothing is drawn there)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 896   px  the bezel around the game screen
  save.png                 260 x 132   px  a quick action on the frame, bind quickSave
  load.png                 259 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                260 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         259 x 132   px  a quick action on the frame, bind toggleFastForward
  menu.png                 156 x 126   px  a button, bind menu
  dpad.png                 470 x 482   px  the D-pad, bind dpad
  dpad-ball.png            345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  b.png                    282 x 293   px  a button, bind b
  keypad-toggle.png        198 x 72    px  a button, bind keypadToggle
  keypad/background.png   2178 x 1812  px  the keypad page, behind everything
  keypad/save.png          260 x 132   px  a quick action on the frame, bind quickSave
  keypad/load.png          259 x 132   px  a quick action on the frame, bind quickLoad
  keypad/turbo.png         260 x 132   px  a quick action on the frame, bind turbo
  keypad/fast-forward.png   259 x 132   px  a quick action on the frame, bind toggleFastForward
  keypad/menu.png          156 x 126   px  a button, bind menu
  keypad/dpad.png          470 x 482   px  the D-pad, bind dpad
  keypad/dpad-ball.png     345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  keypad/key-1.png         154 x 140   px  a keypad key, bind keypad1
  keypad/key-2.png         154 x 140   px  a keypad key, bind keypad2
  keypad/key-3.png         154 x 140   px  a keypad key, bind keypad3
  keypad/key-4.png         154 x 139   px  a keypad key, bind keypad4
  keypad/key-5.png         154 x 139   px  a keypad key, bind keypad5
  keypad/key-6.png         154 x 139   px  a keypad key, bind keypad6
  keypad/key-7.png         154 x 140   px  a keypad key, bind keypad7
  keypad/key-8.png         154 x 140   px  a keypad key, bind keypad8
  keypad/key-9.png         154 x 140   px  a keypad key, bind keypad9
  keypad/key-star.png      154 x 140   px  a keypad key, bind keypadStar
  keypad/key-0.png         154 x 140   px  a keypad key, bind keypad0
  keypad/key-hash.png      154 x 140   px  a keypad key, bind keypadHash
  keypad/keypad-toggle.png   198 x 72    px  a button, bind keypadToggle

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, O2-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/O2/ on the device.
  3. Start a Odyssey² game. Delete the folder to go back to the bundled skin.
