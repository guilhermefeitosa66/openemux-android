Saturn skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 36, 36, 1008 x 756 px (left clear: nothing is drawn there)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png               1044 x 864   px  the bezel around the game screen
  save.png                 261 x 90    px  a quick action on the frame, bind quickSave
  load.png                 261 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                261 x 90    px  a quick action on the frame, bind turbo
  fast-forward.png         261 x 90    px  a quick action on the frame, bind toggleFastForward
  l.png                    372 x 129   px  a button, bind l
  r.png                    372 x 129   px  a button, bind r
  menu.png                 156 x 108   px  a button, bind menu
  dpad.png                 420 x 432   px  the D-pad, bind dpad
  dpad-ball.png            308 x 308   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    114 x 123   px  a button, bind x
  y.png                    114 x 123   px  a button, bind y
  z.png                    114 x 123   px  a button, bind z
  a.png                    156 x 165   px  a button, bind a
  b.png                    156 x 165   px  a button, bind b
  c.png                    156 x 165   px  a button, bind c
  start.png                162 x 60    px  a button, bind start

phone-landscape/  (2238 x 1080 px)
  game screen at 491, 36, 1256 x 942 px (left clear: nothing is drawn there)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png               1292 x 1044  px  the bezel around the game screen
  save.png                 323 x 84    px  a quick action on the frame, bind quickSave
  load.png                 323 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                323 x 84    px  a quick action on the frame, bind turbo
  fast-forward.png         323 x 84    px  a quick action on the frame, bind toggleFastForward
  l.png                    372 x 123   px  a button, bind l
  r.png                    372 x 123   px  a button, bind r
  menu.png                 156 x 96    px  a button, bind menu
  dpad.png                 361 x 374   px  the D-pad, bind dpad
  dpad-ball.png            265 x 265   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                     96 x 104   px  a button, bind x
  y.png                     96 x 103   px  a button, bind y
  z.png                     96 x 103   px  a button, bind z
  a.png                    131 x 139   px  a button, bind a
  b.png                    131 x 139   px  a button, bind b
  c.png                    131 x 139   px  a button, bind c
  start.png                162 x 60    px  a button, bind start

tablet-portrait/  (1600 x 2560 px)
  game screen at 52, 52, 1496 x 1122 px (left clear: nothing is drawn there)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1536 x 1230  px  the bezel around the game screen
  save.png                 384 x 88    px  a quick action on the frame, bind quickSave
  load.png                 384 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                384 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         384 x 88    px  a quick action on the frame, bind toggleFastForward
  l.png                    340 x 102   px  a button, bind l
  r.png                    340 x 102   px  a button, bind r
  menu.png                 104 x 88    px  a button, bind menu
  dpad.png                 314 x 322   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                     86 x 92    px  a button, bind x
  y.png                     86 x 92    px  a button, bind y
  z.png                     86 x 92    px  a button, bind z
  a.png                    116 x 123   px  a button, bind a
  b.png                    116 x 123   px  a button, bind b
  c.png                    116 x 124   px  a button, bind c
  start.png                132 x 48    px  a button, bind start

tablet-landscape/  (2560 x 1600 px)
  game screen at 500, 181, 1560 x 1170 px (left clear: nothing is drawn there)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png               1600 x 1278  px  the bezel around the game screen
  save.png                 400 x 88    px  a quick action on the frame, bind quickSave
  load.png                 400 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                400 x 88    px  a quick action on the frame, bind turbo
  fast-forward.png         400 x 88    px  a quick action on the frame, bind toggleFastForward
  l.png                    340 x 102   px  a button, bind l
  r.png                    340 x 102   px  a button, bind r
  menu.png                 104 x 84    px  a button, bind menu
  dpad.png                 314 x 322   px  the D-pad, bind dpad
  dpad-ball.png            230 x 230   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                     86 x 92    px  a button, bind x
  y.png                     86 x 92    px  a button, bind y
  z.png                     86 x 92    px  a button, bind z
  a.png                    116 x 123   px  a button, bind a
  b.png                    116 x 123   px  a button, bind b
  c.png                    116 x 124   px  a button, bind c
  start.png                132 x 48    px  a button, bind start

fold-portrait/  (1812 x 2178 px)
  game screen at 325, 78, 1162 x 871 px (left clear: nothing is drawn there)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png               1222 x 1033  px  the bezel around the game screen
  save.png                 306 x 132   px  a quick action on the frame, bind quickSave
  load.png                 305 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                305 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         306 x 132   px  a quick action on the frame, bind toggleFastForward
  l.png                    510 x 153   px  a button, bind l
  r.png                    510 x 153   px  a button, bind r
  menu.png                 156 x 132   px  a button, bind menu
  dpad.png                 350 x 362   px  the D-pad, bind dpad
  dpad-ball.png            257 x 257   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                     95 x 102   px  a button, bind x
  y.png                     95 x 102   px  a button, bind y
  z.png                     96 x 102   px  a button, bind z
  a.png                    130 x 138   px  a button, bind a
  b.png                    130 x 137   px  a button, bind b
  c.png                    130 x 138   px  a button, bind c
  start.png                198 x 72    px  a button, bind start

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 488, 978 x 734 px (left clear: nothing is drawn there)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 896   px  the bezel around the game screen
  save.png                 260 x 132   px  a quick action on the frame, bind quickSave
  load.png                 259 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                260 x 132   px  a quick action on the frame, bind turbo
  fast-forward.png         259 x 132   px  a quick action on the frame, bind toggleFastForward
  l.png                    498 x 153   px  a button, bind l
  r.png                    498 x 153   px  a button, bind r
  menu.png                 156 x 126   px  a button, bind menu
  dpad.png                 470 x 482   px  the D-pad, bind dpad
  dpad-ball.png            345 x 345   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  x.png                    118 x 127   px  a button, bind x
  y.png                    118 x 128   px  a button, bind y
  z.png                    119 x 127   px  a button, bind z
  a.png                    162 x 171   px  a button, bind a
  b.png                    162 x 171   px  a button, bind b
  c.png                    162 x 171   px  a button, bind c
  start.png                198 x 72    px  a button, bind start

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, SATURN-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/SATURN/ on the device.
  3. Start a Saturn game. Delete the folder to go back to the bundled skin.
