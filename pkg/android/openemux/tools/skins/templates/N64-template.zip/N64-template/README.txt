Nintendo 64 skin template for OpenEmux (Android)

A controller skin in OpenEmux's own format, with plain placeholder art at the exact sizes the app reads.
Repaint the images, keep their names and sizes, and install the folder. The guide (files, layouts,
colours, binds, import) is tools/skins/templates/README.md in the openemux-android repository:
https://github.com/guilhermefeitosa66/openemux-android/blob/openemux-mobile/pkg/android/openemux/tools/skins/templates/README.md

Every image is optional: a missing one is drawn from the colours, shape and label in skin.json.
sources/<layout>.svg puts a layout's images together, one layer each, to paint them in context.

phone-portrait/  (1080 x 2238 px)
  game screen at 36, 36, 1008 x 756 px (left clear: nothing is drawn there)
  background.png          1080 x 2238  px  the whole layout, behind everything
  frame.png               1044 x 864   px  the bezel around the game screen
  save.png                 209 x 90    px  a quick action on the frame, bind quickSave
  load.png                 209 x 90    px  a quick action on the frame, bind quickLoad
  turbo.png                208 x 90    px  a quick action on the frame, bind turbo
  slow-motion.png          209 x 90    px  a quick action on the frame, bind slowMotion
  fast-forward.png         209 x 90    px  a quick action on the frame, bind toggleFastForward
  l.png                    372 x 129   px  a button, bind l
  r.png                    372 x 129   px  a button, bind r
  menu.png                 156 x 102   px  a button, bind menu
  stick-base.png           336 x 336   px  the stick's well, bind analogStick
  stick-knob.png           168 x 168   px  the stick's knob, moved by the thumb, bind analogStick
  c-up.png                  98 x 107   px  a button, bind cUp
  c-left.png                98 x 107   px  a button, bind cLeft
  c-right.png               98 x 107   px  a button, bind cRight
  c-down.png                98 x 107   px  a button, bind cDown
  b.png                    155 x 164   px  a button, bind b
  a.png                    167 x 176   px  a button, bind a
  z.png                    126 x 135   px  a button, bind z
  dpad.png                 300 x 312   px  the D-pad, bind dpad
  dpad-ball.png            220 x 220   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  start.png                162 x 60    px  a button, bind start

phone-landscape/  (2238 x 1080 px)
  game screen at 491, 36, 1256 x 942 px (left clear: nothing is drawn there)
  background.png          2238 x 1080  px  the whole layout, behind everything
  frame.png               1292 x 1044  px  the bezel around the game screen
  save.png                 258 x 84    px  a quick action on the frame, bind quickSave
  load.png                 259 x 84    px  a quick action on the frame, bind quickLoad
  turbo.png                258 x 84    px  a quick action on the frame, bind turbo
  slow-motion.png          259 x 84    px  a quick action on the frame, bind slowMotion
  fast-forward.png         258 x 84    px  a quick action on the frame, bind toggleFastForward
  l.png                    372 x 123   px  a button, bind l
  r.png                    372 x 123   px  a button, bind r
  menu.png                 156 x 90    px  a button, bind menu
  stick-base.png           254 x 254   px  the stick's well, bind analogStick
  stick-knob.png           127 x 127   px  the stick's knob, moved by the thumb, bind analogStick
  c-up.png                  73 x 79    px  a button, bind cUp
  c-left.png                73 x 79    px  a button, bind cLeft
  c-right.png               73 x 79    px  a button, bind cRight
  c-down.png                73 x 79    px  a button, bind cDown
  b.png                    116 x 122   px  a button, bind b
  a.png                    125 x 131   px  a button, bind a
  z.png                     94 x 101   px  a button, bind z
  dpad.png                 227 x 239   px  the D-pad, bind dpad
  dpad-ball.png            166 x 166   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  start.png                162 x 60    px  a button, bind start

tablet-portrait/  (1600 x 2560 px)
  game screen at 52, 52, 1496 x 1122 px (left clear: nothing is drawn there)
  background.png          1600 x 2560  px  the whole layout, behind everything
  frame.png               1536 x 1230  px  the bezel around the game screen
  save.png                 307 x 88    px  a quick action on the frame, bind quickSave
  load.png                 307 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                308 x 88    px  a quick action on the frame, bind turbo
  slow-motion.png          307 x 88    px  a quick action on the frame, bind slowMotion
  fast-forward.png         307 x 88    px  a quick action on the frame, bind toggleFastForward
  l.png                    340 x 102   px  a button, bind l
  r.png                    340 x 102   px  a button, bind r
  menu.png                 104 x 84    px  a button, bind menu
  stick-base.png           250 x 250   px  the stick's well, bind analogStick
  stick-knob.png           125 x 125   px  the stick's knob, moved by the thumb, bind analogStick
  c-up.png                  76 x 83    px  a button, bind cUp
  c-left.png                77 x 83    px  a button, bind cLeft
  c-right.png               76 x 83    px  a button, bind cRight
  c-down.png                76 x 83    px  a button, bind cDown
  b.png                    121 x 127   px  a button, bind b
  a.png                    130 x 137   px  a button, bind a
  z.png                     99 x 105   px  a button, bind z
  dpad.png                 224 x 232   px  the D-pad, bind dpad
  dpad-ball.png            164 x 164   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  start.png                132 x 48    px  a button, bind start

tablet-landscape/  (2560 x 1600 px)
  game screen at 500, 181, 1560 x 1170 px (left clear: nothing is drawn there)
  background.png          2560 x 1600  px  the whole layout, behind everything
  frame.png               1600 x 1278  px  the bezel around the game screen
  save.png                 320 x 88    px  a quick action on the frame, bind quickSave
  load.png                 320 x 88    px  a quick action on the frame, bind quickLoad
  turbo.png                320 x 88    px  a quick action on the frame, bind turbo
  slow-motion.png          320 x 88    px  a quick action on the frame, bind slowMotion
  fast-forward.png         320 x 88    px  a quick action on the frame, bind toggleFastForward
  l.png                    340 x 102   px  a button, bind l
  r.png                    340 x 102   px  a button, bind r
  menu.png                 104 x 80    px  a button, bind menu
  stick-base.png           250 x 251   px  the stick's well, bind analogStick
  stick-knob.png           125 x 125   px  the stick's knob, moved by the thumb, bind analogStick
  c-up.png                  76 x 83    px  a button, bind cUp
  c-left.png                77 x 83    px  a button, bind cLeft
  c-right.png               76 x 83    px  a button, bind cRight
  c-down.png                76 x 83    px  a button, bind cDown
  b.png                    121 x 128   px  a button, bind b
  a.png                    130 x 136   px  a button, bind a
  z.png                     99 x 106   px  a button, bind z
  dpad.png                 224 x 232   px  the D-pad, bind dpad
  dpad-ball.png            164 x 164   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  start.png                132 x 48    px  a button, bind start

fold-portrait/  (1812 x 2178 px)
  game screen at 325, 78, 1162 x 871 px (left clear: nothing is drawn there)
  background.png          1812 x 2178  px  the whole layout, behind everything
  frame.png               1222 x 1033  px  the bezel around the game screen
  save.png                 244 x 132   px  a quick action on the frame, bind quickSave
  load.png                 245 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                244 x 132   px  a quick action on the frame, bind turbo
  slow-motion.png          245 x 132   px  a quick action on the frame, bind slowMotion
  fast-forward.png         244 x 132   px  a quick action on the frame, bind toggleFastForward
  l.png                    510 x 153   px  a button, bind l
  r.png                    510 x 153   px  a button, bind r
  menu.png                 156 x 126   px  a button, bind menu
  stick-base.png           164 x 164   px  the stick's well, bind analogStick
  stick-knob.png            82 x 82    px  the stick's knob, moved by the thumb, bind analogStick
  c-up.png                  49 x 54    px  a button, bind cUp
  c-left.png                50 x 54    px  a button, bind cLeft
  c-right.png               50 x 54    px  a button, bind cRight
  c-down.png                49 x 55    px  a button, bind cDown
  b.png                     79 x 83    px  a button, bind b
  a.png                     85 x 90    px  a button, bind a
  z.png                     65 x 69    px  a button, bind z
  dpad.png                 146 x 159   px  the D-pad, bind dpad
  dpad-ball.png            107 x 107   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  start.png                198 x 72    px  a button, bind start

fold-landscape/  (2178 x 1812 px)
  game screen at 600, 488, 978 x 734 px (left clear: nothing is drawn there)
  background.png          2178 x 1812  px  the whole layout, behind everything
  frame.png               1038 x 896   px  the bezel around the game screen
  save.png                 208 x 132   px  a quick action on the frame, bind quickSave
  load.png                 207 x 132   px  a quick action on the frame, bind quickLoad
  turbo.png                208 x 132   px  a quick action on the frame, bind turbo
  slow-motion.png          207 x 132   px  a quick action on the frame, bind slowMotion
  fast-forward.png         208 x 132   px  a quick action on the frame, bind toggleFastForward
  l.png                    498 x 153   px  a button, bind l
  r.png                    498 x 153   px  a button, bind r
  menu.png                 156 x 120   px  a button, bind menu
  stick-base.png           376 x 376   px  the stick's well, bind analogStick
  stick-knob.png           188 x 188   px  the stick's knob, moved by the thumb, bind analogStick
  c-up.png                  89 x 97    px  a button, bind cUp
  c-left.png                90 x 98    px  a button, bind cLeft
  c-right.png               90 x 98    px  a button, bind cRight
  c-down.png                89 x 97    px  a button, bind cDown
  b.png                    143 x 150   px  a button, bind b
  a.png                    153 x 161   px  a button, bind a
  z.png                    116 x 124   px  a button, bind z
  dpad.png                 336 x 348   px  the D-pad, bind dpad
  dpad-ball.png            246 x 246   px  the D-pad's ball, moved by the thumb over the pad, bind dpad
  start.png                198 x 72    px  a button, bind start

Install (until the app can import a zip):

  1. Unzip this file: it gives one folder, N64-template/ (rename it if you like).
  2. Copy that folder into Android/data/com.openemux.mobile/files/skins/N64/ on the device.
  3. Start a Nintendo 64 game. Delete the folder to go back to the bundled skin.
